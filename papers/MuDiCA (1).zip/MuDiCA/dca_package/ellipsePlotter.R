#########################################################################################	
# This function takes care of the Ellipses for tolerance, prediction (both _SmallN) and bootstrap (_BigN)
# A more graceful solution to the ellipse is required. 
#########################################################################################	

ellipsePlotter <- function(obs,centers,cps,axis1,axis2,classes,uniqueClasses,minMaxList,catcher=FALSE,interval=0.95,main="",sub="",xlab="",ylab=""){

	minx = minMaxList$minx
	miny = minMaxList$miny
	maxx = minMaxList$maxx
	maxy = minMaxList$maxy
	
	plotCatcher = catcher
	for(j in 1:dim(uniqueClasses)[1]){
		groupStorageMatrix <- matrix(0,0,dim(obs)[2])
		for(i in 1:dim(classes)[1]){
			rowEq <- (classes[i,] == uniqueClasses[j,])
			#A neat little trick to calculate whole vector equivalency!
			#if((rowEq %*% t(rowEq)) == dim(classes)[2]){
			if(sqrt(sum((rowEq %*% t(rowEq)))) == dim(classes)[2]){
				#PUT obs into temp Mat
				groupStorageMatrix <- rbind(groupStorageMatrix,obs[i,])
				
			}
		}
		
		#Call pca_draw_ellipse
		ellipsePoints = PCAEllipse_SmallN(cbind(groupStorageMatrix[,axis1],groupStorageMatrix[,axis2]),interval=interval)
		
				
		ellipsePlusCenters = as.matrix(cbind((ellipsePoints[,1] + centers[,axis1]),(ellipsePoints[,2] + centers[,axis2])))
		ellipseMinusCenters = as.matrix(cbind((ellipsePoints[,1] - centers[,axis1]),(ellipsePoints[,2] - centers[,axis2])))		
		mmTemp <- minmaxHelper(ellipsePlusCenters,ellipseMinusCenters)	
		c = as.numeric(cps[j,1])		
		if(plotCatcher){
			points(ellipsePoints,ylim=c(miny,maxy),xlim=c(minx,maxx),col=c,type='l')
		}else{
			plot(ellipsePoints,ylim=c(miny,maxy),xlim=c(minx,maxx),col=c,type='l',pos=0,main=main,sub=sub,xlab=xlab,ylab=ylab)
			plotCatcher = TRUE
		}
	}
}

#This works only for the two dimensional case.
PCAEllipse_SmallN <- function(points,interval=0.95,center=NaN){
## If no center is passed in, find it.
	if(is.nan(center)){
		center = colMeans(points)
	}
	thisCenter = t(as.matrix(center))


##SVD (aka party) time.	
	ret_PDQ <- PDQ(points - matrix(1,dim(points)[1],1)%*%thisCenter)
	F = ret_PDQ$p %*% ret_PDQ$Dd
	c = ret_PDQ$Dv[1] / ret_PDQ$Dv[2]	
	y_length = (max(sqrt((F[,1]^2)/(c^2) + (F[,2]^2)))) * interval
	x_length = (y_length * c) * interval

	
##Ellipse time.
	j = seq(pi/64,2*pi,by=pi/64)
	coords = cbind(cos(j)*x_length,sin(j)*y_length)
	ellipseCoords = (coords %*% t(ret_PDQ$q) + matrix(1,dim(as.matrix(j))[1],1) %*% thisCenter)
	return(ellipseCoords)
}


PCAEllipse_BigN <-function(X,interval=0.95){

	X = as.matrix(X)
	X_dims = dim(X)
	center_xy = t(as.matrix(colSums(X)/X_dims[1]))
	dist_X = cbind(fastEucCalc(X,center_xy),X)
	C = dist_X[order(dist_X[,1]),]
	eliminateRows = seq(from=(floor(interval*X_dims[1])+1),to=X_dims[1])	
	C = C[-eliminateRows,-1]
	C_dims = dim(C)
	center_xyC = t(as.matrix(colSums(C)/C_dims[1]))
	
	ret_PDQ <- fastPDQ(C - matrix(1,C_dims[1],1)%*%center_xyC)
	F = ret_PDQ$p %*% diag(ret_PDQ$Dv)
	F_temp = abs(F)		
	prop = ret_PDQ$Dv[1]/ret_PDQ$Dv[2]
	y_length = max(sqrt((F_temp[,1]^2/prop^2) + F_temp[,2]^2))	
	x_length = y_length * prop
	j = seq(pi/64,2*pi,by=pi/64)
	coords = cbind(cos(j)*x_length,sin(j)*y_length)
	ellipseCoords = ((coords %*% t(ret_PDQ$q)) + (matrix(1,dim(as.matrix(j))[1],1) %*% center_xyC))
	return(ellipseCoords)
}

