#########################################################################################	
#Plotting function for observations and centers for fixed and random effect.
#########################################################################################	

dataPlotter <- function(plotting_data,cps,axis1,axis2,classes,uniqueClasses,minMaxList,catcher=FALSE,pinc=0,m="",s="",textorpoint=0,xl,yl){

	minx = minMaxList$minx
	miny = minMaxList$miny
	maxx = minMaxList$maxx
	maxy = minMaxList$maxy
	
	plotCatcher = catcher
	for(i in 1:dim(classes)[1]){
		for(j in 1:dim(uniqueClasses)[1]){
			rowEq <- (classes[i,] == uniqueClasses[j,])
			#A neat little trick to calculate whole vector equivalency!
			#if((rowEq %*% t(rowEq)) == dim(classes)[2]){
			if(sqrt(sum((rowEq %*% t(rowEq)))) == dim(classes)[2]){
				#SUCCESS!
				pt = as.numeric(cps[j,2])
				wd = 1
				if(pinc == 1){
					#pt = pt + pinc;
					#I can ask for unique class labels HERE for plotting barycenters
					wd = 10
				}
				c = as.numeric(cps[j,1])			
				if(plotCatcher){
					#data_out name dependent on what is incoming.
					if(textorpoint == 0){
						points(plotting_data[i,axis1],plotting_data[i,axis2],pch=pt,col=c,lwd=wd)					
					}else{
						text(plotting_data[i,axis1],plotting_data[i,axis2],colnames(classes)[i],col=c)
					}
				}else{
					#data_out name dependent on what is incoming.				
					if(textorpoint == 0){
						plot(plotting_data[i,axis1],plotting_data[i,axis2],ylim=c(miny,maxy),xlim=c(minx,maxx),pch=pt,col=c,pos=0,lwd=wd,main=m,sub=s,xlab=xl,ylab=yl)					
					}else{
						plot(plotting_data[i,axis1],plotting_data[i,axis2],ylim=c(miny,maxy),xlim=c(minx,maxx),pch=pt,col=c,pos=0,lwd=wd,main=m,sub=s,type="n",xlab=xl,ylab=yl)
						text(plotting_data[i,axis1],plotting_data[i,axis2],colnames(classes)[i],col=c)
					}
					plotCatcher = TRUE
				}
			}
		}
	}
}