fastPDQ <- function(datain,k=0){

	dataDims <- dim(datain)
	I <- dataDims[1]
	J <- dataDims[2]

	m <- min(c(I,J))
	flip <- 0
	
	if (I < J){
		datain <- t(datain)
		flip <- 1
	}
	precisionLimit = 2*.Machine$double.eps
	#eigen in R returns the same as HA`s eigen
	eigOut <- eigen(t(datain) %*% datain)
	Q <- eigOut$vectors
	D <- eigOut$values
	indToKeep = which(D > precisionLimit)
	if((length(indToKeep) > k) && (k != 0)){
		indToKeep = indToKeep[1:k]
	}
	Q <- Q[,indToKeep]
	D <- D[indToKeep]
	
	D <- sqrt(D) 
	
	P <- datain %*% Q %*% solve(diag(D))

	if(flip==1){
		temp=Q
		Q=P
		P=temp
	}
	return(list(p=P,Dv=D,Dd=diag(D),q=Q,ng=length(D)))
}