function  [Fboot]=BootDCABal(X,G,fj,lambda,niter);
%USAGE [FBoot]=BootDCABal(X,G,fj,lambda,niter]
% Perform a bootstrap on the result 
% of a DCA analysis
% To be used AFTER a call to a DICA program
%                         (e.g., DCA_pred)
% X is the data matrix (for all observations) nI*nJ
% G is a 0/1 group indicator matrix [g(i,k)=1 if obs  i is in group k]
%    nI*nK
% fi is the nJ*nfact J-factors from the DICA 
% niter in the # of iterations for the bootstrap
% (default is 1000)
% The bootstrap is performed by resampling with replacement
% FBoot is the set of matrices with the
% niter projections of the bootstraped samples
% 
% Here the bootstrap is performed for each group separately
% i.e., the number of observations per group is constant
% Method: for each iteration we sample with replacement
% compute a nK*nJ group barycenter and project it on the
% DCA solution as supplementary elements
% Herve Abdi November 2008
% Current version February 2010
% herve@utdallas.edu www.utdallas.edu/~herve
% 

% niter is the number of bootstrap iterations
if exist('niter')~=1;
   niter=1000;
end
% Check that G is a 0/1 matrix if not make it
% 
if size(G,2)==1;G=dummy_of(G);end
if size(G,1)~=size(X,1)
   error(['Incompatible Number of Row for X & G'])
end

disp(['DCA Bootstrap for ',int2str(niter),' iterations'])
% Start Bootstrap here
% 
% 
% Here 
%  nc    is # of categories
%  nI    is # of observations
% nfact  is # of factors
% niter  is # of iteration for bootstrap
% fj     is factors on J set
% lambda is eigenvalue from DCA
% G      is dummy coded matrix for the group (0/1) values
nfact=size(fj,2);
nc=size(G,2);
nI=size(X,1);
% Initialize the result matrix
Fboot=zeros(nc, nfact, niter);
npg=sum(G);
% *******************************************************************
% loop on niter
bootint=zeros(nI);
ncount=0;nperdisplay=round(niter/10);
disp('Starting Bootstrap')
for n=1:niter;
ncount=ncount+1;
    if ncount==nperdisplay;ncount=0;
   %   disp(['   Bootstrap Iteration #: ',int2str(n),'/',int2str(niter)])
     leMess=['   Bootstrap Iteration #: ',int2str(n),'/',int2str(niter)];
      if n>nperdisplay;    for tt=1:nle;fprintf('\b');end
      end
      fprintf('%s%',leMess);nle=length(leMess);
    end
 %  
 %  bootint=BootIndice(nI)
    bootint=BootIndiceBal(npg);
    Xboot=X(bootint,:);
    % Gboot=G(bootint,:);
    Xsum_boot=G'*Xboot;
    [f_boot]=afc_sup(Xsum_boot,fj,lambda);
    Fboot(:,:,n)=f_boot;
end
fprintf('\r')

% ********************************************************************
% The functions here
% BootIndices,   BootIndiceBal, dummy_of & afc_sup 
% 
 function [bb ] = BootIndiceBal(npg )
%  [Btbal ] = BootIndeiceBal(npg )
%  Gives Bootstrap indices for Group
%  npg is a vector of group size
%  The indices will correspond to the 
% Bootstrap indices such that the
% Bootstrap samples have the same group size
% as the original groups
 jj=1;
nc=length(npg);
bb=zeros(sum(npg),1);
for i=1:nc;
   bb(jj:jj+npg(i)-1)=BootIndice(npg(i))+jj-1;
   jj=jj+npg(i);
end

function y = BootIndice(n)
% USAGE [Indices]=BootIndice(N);
% Give a set of N integers corresponding 
% to a sampling with replacement
% Use to implement BOOTSTRAP% 
 y = ceil(n .* rand(n,1));  

function  [Xrec,nom_c]=dummy_of(x)
% USAGE [Xrecnval]=dummy_of(x)
% transform a vector x into a dummy matrix X
% x is a vector with different values
% (not ordered and with possible gaps
% Xrec is dummy coding matrix
% after the values of x have been 
%   replaced by unique ordered values
% nval i a string array 
%   it gives the recoding values for x
%   (i.e. the columns of Xrec)
% Herve Abdi January 2006
[U_S,m,recS]=unique(x);
% U_S containts the "unique values of S
% recS containts the renumbered values
n_S=length(m);
% # of different values of S
ni=length(x) ;
Xrec=zeros(ni,n_S);
les_uns=sub2ind(size(Xrec),  [1:ni]',recS);
%dummy_S([ [1:ni]',recS])=ones(ni,1)
Xrec(les_uns)=1;
nval_n=x(m);
n=0;
for k=1:length(nval_n);
nom_c(k)={[num2str(nval_n(k))]}; 
end

function  [f_sup]=afc_sup(X_sup,F,l);
%USAGE [f_sup]=afc_sup(X_sup,F,l); correspondence analysis
%Compute supplementary elements for 
% Correspondence analysis
% need X_sup: the matrix of elements to compute
%             ALWAYS SUPPOSED TO BE ROWS!!!
%      F    : the coordinates of the other set
%              (i.e., if X_sup are rows F is G_i
%               the columns coordinates)
%      l    :  vector of the eigenvalues
%
%%%%%%%%%%%   Herve Abdi October 2004 %%%%%%%%%%%%%%
[n_sup,nvar]=size(X_sup);
[nvar2,nl]=size(F);
[nl2,toto]=size(l);
 if toto~=1;l=l';[nl2,toto]=size(l);end;
 if toto~=1;error('eigenvalues should be a vector');end
 if nvar~=nvar2;error('Dimensions fo X_sup and F should match');end
 if nl~=nl2;error('Dimensions of F and l should match');end
inv_delta=l.^(-1/2);
profile=X_sup./((sum(X_sup')')*ones(1,nvar) );
f_sup=profile*F*diag(inv_delta);