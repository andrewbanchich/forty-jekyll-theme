#This will always use (0,0) as the origin. An overload can happen later.
#determineAxesPosition <- function(data_matrix,x_axis,y_axis,supplementary_matrix=NULL){
determineAxesPosition <- function(min_max_list){
#	if(is.null(supplementary_matrix)){
#		minMaxList <- minmaxHelper(data_matrix,data_matrix,x_axis,y_axis)
#	}else{
#		minMaxList <- minmaxHelper(data_matrix,supplementary_matrix,x_axis,y_axis)
#	}
	minx <- min_max_list$minx
	miny <- min_max_list$miny
	maxx <- min_max_list$maxx
	maxy <- min_max_list$maxy
	x_axis_y_pos <- c(0,0)
	y_axis_x_pos <- c(0,0)
	y_axis_y_pos <- c(miny,maxy)
	x_axis_x_pos <- c(minx,maxx)
	return(list(xx=x_axis_x_pos,xy=x_axis_y_pos,yy=y_axis_y_pos,yx=y_axis_x_pos))
}

makeNewPlotWindow <- function(axis_position_list,min_max_list,x_label="",y_label="",main_label="",axis_line_width=3){
	#This should make a blank plot window with custom placed axes and labels.
	dev.new()
	#not sure yet...
	plot(c(0,0),c(0,0),type="n",col="white",axes=FALSE,xlab=x_label,ylab=y_label,ylim=c(min_max_list$miny,min_max_list$maxy),xlim=c(min_max_list$minx,min_max_list$maxx),main=main_label)
	points(axis_position_list$xx,axis_position_list$xy,type="l",col="black",lwd=axis_line_width)
	points(axis_position_list$yx,axis_position_list$yy,type="l",col="black",lwd=axis_line_width)	
}
