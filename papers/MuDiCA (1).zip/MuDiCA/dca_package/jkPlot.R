###
# A plot function for jackknifed data. However, this calls into dcaPlot, which is the primary plotting function for this DCA code base.
# dcaPlot does quite a bit, actually.
# This function mostly just calculates the jackknifed barycenters of each group.
###

jkPlot <- function(obs,cpsu,fixed_centers,classes,axis1,axis2,lambda,minMaxList,plot_ells=0.95,plot_centers=1,plot_points=1,plot_ellipses=1,show_points=1,main="",sub="",xlab="",ylab="",jkCenter=0){
	centers = fixed_centers
	if(jkCenter == 1){
		centers = matrix(0,dim(fixed_centers)[1],dim(fixed_centers)[2])
		for(j in 1:dim(cpsu$uc)[1]){
			predGroupBary <- matrix(0,0,dim(fixed_centers)[2])
			for(i in 1:dim(obs)[1]){
				rowEq <- (classes[i,] == cpsu$uc[j,])
				if(sqrt(sum((rowEq %*% t(rowEq)))) == dim(classes)[2]){
					predGroupBary <- rbind(predGroupBary,obs[i,])
				}
			}
			centers[j,] <- colMeans(predGroupBary)
		}
	}	
	dcaPlot(cpsu,axis1,axis2,classes,centers,obs,lambda,minMaxList,plot_ellipses=plot_ells,main=main,sub=sub,xlab=xlab,ylab=ylab)
}