# an [R] companion to the MatLab code provided by Dr. Hervé Abdi for:

#Williams, L.J., Abdi, H., French, R., & Orange, J.B. (in press, 2010). 
#A tutorial on Multi-Block Discriminant Correspondence Analysis (MUDICA): A new method for analyzing discourse data from clinical populations. 
#Journal of Speech Language and Hearing Research, 53.

# [R] code for MuDiCA by Derek Beaton.
#	with lots of code translated directly from Dr. Hervé Abdi`s MatLab code.
#	see comments and notations in code.

source("MuDICA/dca_package/loadStuff.R")

# a little bit of hackery, for cleanliness.
MuDiCAcleanup()
MuDiCA_2010_results = 0
remove(MuDiCA_2010_results)


print('MuDICA Example')
print('Williams, L.J., Abdi, H., French, R., & Orange, J.B. (in press, 2010). A tutorial on Multi-Block Discriminant Correspondence Analysis (MUDICA): A new method for analyzing discourse data from clinical populations. Journal of Speech Language and Hearing Research, 53.')

your_data_matrix = "MuDICA/dca_package/data/MuDICA_AD_data.csv"
your_group_matrix = "MuDICA/dca_package/data/MuDICA_AD_classes.csv"
your_block_matrix = "MuDICA/dca_package/data/MuDICA_AD_blocks.csv"
your_supplementary_observations = 0 

#1 for yes, 0 for no
do_you_want_to_plot_blocks = 1

#TRUE for yes, FALSE for no
data_matrices_have_variables_in_them = TRUE

#1 for files, 0 for [R] data
using_files_or_R_data = 1

#1 for yes, 0 for no to perform Jackknife prediction
perform_prediction = 1

#0 for no, Greater than 100 to run bootstrapping
bootstraps = 1000

#1 for yes, 0 for no
plot_variables_with_observations = 1

#0 for no ellipses, Greater than zero for showing ellipses
interval_treshold = 0.95

#0 for no, Greater than 2 for performing group-wise Sidak multiple comparisons correction
number_of_corrections = 0

#Name of the plots main text:
your_plot_text = "DICA AD & Spouses"


MuDiCA_2010_results = MUDICA_DEMO(data_mat=your_data_matrix,group_mat=your_group_matrix,block_mat=your_block_matrix,sup_mat=your_supplementary_observations,interval=interval_treshold,plot_block_data=do_you_want_to_plot_blocks,vars=data_matrices_have_variables_in_them,file_mat_flag=using_files_or_R_data,jackknife=perform_prediction,boot_sample=bootstraps,variable_plots=plot_variables_with_observations,num_comparisons=number_of_corrections,plot_text=your_plot_text)
#Uncomment the line below to print the output to the screen
#Alternatively, you can type "MuDiCA_2010_results" into the console after running this file.
#print(MuDiCA_2010_results)

#Uncomment the line below to save the output into an R data file.
#save(MuDiCA_2010_results,file="MuDiCA_Results.rda")


#Some Bonus Material. Plotting and getting variables with above expected contribution to variance.
#Follow along here to make customized plots from MuDiCA_2010_results and to also use a more publication friendly graphing utility, prettyGraphs.
axis1 = 1
axis2 = 2
#Expected Contributions:
average_column_contribution <- 1/dim(MuDiCA_2010_results$rd$f)[1]
#above average columns are the factor scores of the j-set, where the contribution of the j-set is above expected on axis1; and combine that with above expected on axis 2.
above_average_columns <- rbind(MuDiCA_2010_results$rd$f[MuDiCA_2010_results$rd$cj[,axis1] > average_column_contribution,],MuDiCA_2010_results$rd$f[MuDiCA_2010_results$rd$cj[,axis2] > average_column_contribution,])
prettyGraphs(above_average_columns,color_vector=matrix("green",dim(above_average_columns)[1]),display_names=FALSE,x_axis=axis1,y_axis=axis2,new_window=TRUE,x_label=round(MuDiCA_2010_results$rd$t[axis1]),y_label=round(MuDiCA_2010_results$rd$t[axis2]),main_label="Above Average Variables for MuDiCA")
prettyGraphs(above_average_columns,color_vector="green",display_names=TRUE,x_axis=axis1,y_axis=axis2,new_window=FALSE)	
#Below will write out the variables and the factor scores (fj), i.e., coordinates.
#write.csv(above_average_columns,file=paste("MUDICA_above_expected_columns_on_factors",axis1,"_and_",axis2,".csv",sep=""))		

MuDiCAcleanup()
