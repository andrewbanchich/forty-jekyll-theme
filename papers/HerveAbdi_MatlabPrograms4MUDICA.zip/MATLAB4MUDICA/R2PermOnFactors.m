function [R2,F,p_rand,p_Fth,R2_sim,F_sim,SSB,SST]=R2PermOnFactors(Fsup,Y,nperm,m_obs);
% USAGE [R2,F,P_perm,p_Fth,R2_sim,F_sim,InB,InT]=R2PermOnFactors(X,G,nperm,m_obs);
% Permutation test to 
% evaluate the probability associated to an R2
% for a DCA-like analysis.
% X is the N*J projection matrix, G the N*K group matrix
% R2 is the squared coeff of correlation for the groups
% F is the F criterion going with R2 F=[R2/(1-R2)]*(df_w/df_b)
% with df_b = K-1 and df_w=N-K
% p_perm is the probability for R2 from the permutation test
% p_Fth is the probability obtained as a Fisher F
% R2_sim, F_sim give the distributions of the simulated R2 and F
% 
% nperm # of permutations default =1000
% This routine uses the projection on the factors
% to compute the test
% This version uses masses for the observations
% (default is equal masses)
% Herve Abdi August, 17 2007/last version November 18 2008.

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%

[nscans,nfact]=size(Fsup);
[nscansY,njY]=size(Y);
if nscans~=nscansY;
    error(['Incompatible numbers of rows for X and G'])
end
if njY==1;
        G=dummy_of(Y);
else
        G=Y;
end
[ngroup]=size(G,2);

% now do permutation test in the Fsup space
% 
if exist('nperm')~=1;nperm=10000;end
if exist('m_obs')~=1;m_obs=ones(nscans,1)*(1/nscans);end
[ntruc,nmachin]=size(m_obs);
if ntruc==1;m_obs=m_obs';[ntruc,nmachin]=size(m_obs);end
if ntruc~=nscans;
    error(['Incompatible numbers of rows for X and m_obs']);
end
if nmachin~=1;
        error(['m_obs should be a vector']);
end
if any(m_obs<0);
            error(['m_obs should be a vector of non negative numbers']);
end
if  abs(sum(m_obs)-1)>10*eps
    warning(['m_obs should sum to one -> m_obs has been rescaled to sum to unity']);
    m_obs=m_obs./sum(m_obs);
end


% Default for nperm

%nperm=1
disp(['Start Randomization tests: for ',...
        int2str(nperm),' iterations']);

[R2,SSB,SST]=R2fromG(Fsup,G,m_obs);
F=(R2./(1-R2)).*( (nscans-ngroup)./(ngroup-1));
p_Fth=fpdf_HA(F,(ngroup-1),(nscans-ngroup));
% go for the permutation now
R2_sim=zeros(1,nperm);
for k0=1:nperm;
  G_sim=G(randpermutation(nscans),:);
  R2_sim(k0)=R2fromG(Fsup,G_sim);
end  
  F_sim=(R2_sim./(1-R2_sim)).*( (nscans-ngroup)./(ngroup-1));

%  F_sim(k0)=(In_B_sim(k0) / (ng-1) ) /( In_W_sim(k0) /(nscans-ng));
%  

disp(['Done Randomization tests']);
p_rand=sum(R2_sim>R2)./nperm;

% inference_results=[' R2=',num2str(R2),...
%         ' F(',num2str(ng-1),',',num2str(nscans-ng),')=',num2str(F_R2),...
%         ' p(Fisher)=',num2str(p_F),' p(randomization)=',num2str(p_rand),...
%         ' (np=',int2str(nperm),')'];
% disp(inference_results);
% 
% % test_mat=[In_W_sim;In_B_sim;In_T_sim;(In_W_sim+In_B_sim);F_sim;R2_sim]';
% 

% The functions here %%%%%%%%%%%%%%%%
function [R2,SSB,SStot]=R2fromG(X,G,m)
% Compute the R2 as the ratio of the 
% between inertia to the total inertia
% 
[nI,nJ]=size(X);
nK=size(G,2);
if exist('m')~=1;m=ones(nI,1)*(1/nI);end
M=G.*repmat(m,1,nK);
Bary=diag(1./sum(M))*(M'*X);
Mg=sum(M)';
Center=Mg'*Bary;
SStot= sum( m.*(sum(   ((X   -repmat(Center,nI,1)) .^2)  ,2)));
% SSB=   sum(Mg.*(sum(   ((Bary-repmat(Center,nK,1)) .^2)  ,2)))
SSB=   sum( m.*(sum(   ((G*Bary-repmat(Center,nI,1)).^2)  ,2)));
%SSW=   sum( m.*(sum(   ((X   -G*Bary).^2)             ,2)))
R2=SSB./SStot;

%
function y = fpdf_HA(x,v1,v2)
%FPDF	F probability density function.
%	Y = FPDF(X,V1,V2) returns the F distribution probability density
%	function with V1 and V2 degrees of freedom at the values in X.
%
%	The size of Y is the common size of the input arguments. A scalar input  
%	functions as a constant matrix of the same size as the other inputs.	 

%	
%	    J. K. Patel, C. H. Kapadia, and D. B. Owen, "Handbook
%	   of Statistical Distributions", Marcel-Dekker, 1976.

if nargin < 3, 
    error('Requires three input arguments.'); 
end

%[errorcode x v1 v2] = distchck(3,x,v1,v2);

%if errorcode > 0
%    error('The arguments must be the same size or be scalars.');
%end
%
%   Initialize Y to zero.
y = zeros(size(x));

k1 = find(v1 < 1 | v2 < 1 | v1 ~= round(v1) | v2 ~= round(v2));
if any(k1)
    y(k1) = NaN * ones(size(k1));
end

k = find(x>0 & v1>=1 & v2>=1 & v1==round(v1) & v2==round(v2));
if any(k)
    xk = x(k);
   temp=(v1(k)./v2(k)).^(v1(k)/2).*xk.^((v1(k)-2)/2)./...
           beta(v1(k)/2,v2(k)/2);
    y(k)=temp.*(1+v1(k)./v2(k).*xk).^(-(v1(k)+v2(k))/2);
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function  [Xrec,nom_c]=dummy_of(x)
% USAGE [Xrecnval]=dummy_of(x)
% transform a vector x into a dummy matrix X
% x is a vector with different values
% (not ordered and with possible gaps
% Xrec is dummy coding matrix
% after the values of x have been 
%   replaced by unique ordered values
% nval i a string array 
%   it gives the recoding values for x
%   (i.e. the columns of Xrec)
% Herve Abdi January 2006
[U_S,m,recS]=unique(x);
% U_S containts the "unique values of S
% recS containts the renumbered values
n_S=length(m);
% # of different values of S
ni=length(x) ;
Xrec=zeros(ni,n_S);
les_uns=sub2ind(size(Xrec),  [1:ni]',recS);
%dummy_S([ [1:ni]',recS])=ones(ni,1)
Xrec(les_uns)=1;
nval_n=x(m);
n=0;
for k=1:length(nval_n);
nom_c(k)={[num2str(nval_n(k))]}; 
end
% End of dummy_of
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function p = randpermutation(n)
%RANDPERM Random permutation.
% USAGE:  p = randperm(n)
% RANDPERM(n) is a random permutation of the integers from 1 to n.
% NB RANDPERM calls RAND and therefore changes RAND's state.

[ignore,p] = sort(rand(1,n));

