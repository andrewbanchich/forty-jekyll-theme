 function [nfig]=PlotUglyBlocks(fi,fj,f_obs,lambda,BlockFactor,Tnum,...
      nom_cat,nom_cats,nom_r,nom_c,nom_tables,...
       LesAxes,ze_title,...
       nfig,imp,gen_name,printype,printextension)
% USAGE  [nfig]=PlotUglyBlocks(fi,fj,f_obs,lambda,BlockFactor,Tnum,...
%      nom_cat,nom_cats,nom_r,nom_c,NomBlocks,...
%       LesAxes,ze_title,...
%       nfig,imp,gen_name,printype,printextension)
%  Plot the blocks for a MUDICA-type of analysis
%  This version uses low level"ugly" matlab plots
% Input parameters 
% fi            : Group factor scores
% fj            : Column factor scores
% f_obs         : Observations factor scores
% lambda        : eigenvalues
% BlockFactor   : Block factor scores (cell array)
% Tnum          : Block indicator vector 
% nom_cat       : Name of the groups
% nom_cats      : Name of the groups for the blocks
% nom_r         : Name of the observations
% nom_c         : Name of the columns
% NomBlocks     : Name of the blocks
% LesAxes       : # of the 2 axes to use for the plots
% ze_title      : Generic title for the graphs
% nfig          : Number of the first figure -1
% imp           : Flag: 1 print=> prind the figures 0 do not
% gen_name      : Generic name for the graph file name 
% printype      : Type of file for printing (e.g.,'-depsc2')
% printextension: File extension for the graphs (e.g., '.eps')
% ************************************************************
% Output is nfig: current # of the active figure
%
% Current Version February 17, 2010. Herve Abdi
% herve@utdallas.edu  www.utdallas.edu/~herve





percent_of_inertia=round( 100*(lambda./sum(lambda)));
axe_horizontal=LesAxes(1);
axe_vertical=LesAxes(2);
[nK]=max(Tnum);     % How many blocks?
[nG,nL]=size(fi);   % How many groups and factors?
[nI]=size(f_obs,1); % How many observations?
[nJ]=size(fj,1);    % How many variables?


% 
All_F=[fi;fj;f_obs];
minc=min(All_F);
maxc=max(All_F);
p=[maxc(1)-minc(1)]/30;
les_axes=[minc(axe_horizontal)-p,maxc(axe_horizontal)+p,...
          minc(axe_vertical)-p,maxc(axe_vertical)+p];  

% Print here
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% Plot here 
nfig=nfig+1;figure(nfig);clf
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %  Now plot the Groups
% %  on the Factors
ze_tRC=[ze_title,' Groups.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
plotxyha(fi,1,2,titre,nom_cat');
axis(les_axes);axis('equal')

AddOn=['Groups'];
% Print the graph if asked for 
if imp==1;
    nom_de_g=[gen_name,AddOn,printextension];
    print(printype,nom_de_g);
end


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nfig=nfig+1;figure(nfig);clf
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %  Now plot the Groups and subtable groups
% %  on the Factors
ze_tRC=[ze_title,' Blocks.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];

% Create the coordiante matrices
%
LesBlocks_fk=zeros(nK,nL);
LesBlocks_fi=zeros(nG*nK,nL);
LesNoms=nom_cat';
for k=1:nK;
 LesNoms=[LesNoms;cellstr(char(nom_cats{:,2}))];
 IndexRow=[(k-1)*nG+1:k*nG];
 LesBlocks_fi(IndexRow,:)= BlockFactor{k}.fi;
 LesBlocks_fk(k,:)= BlockFactor{k}.fk;

end
LesNoms=[LesNoms;cellstr(char(nom_tables{:}))];
    
plotxyha([fi;LesBlocks_fi;LesBlocks_fk],...
    1,2,titre,...
    LesNoms...
     ); axis(les_axes);axis('equal');

AddOn=['Blocks'];
% Print the graph if asked for 
if imp==1;
    nom_de_g=[gen_name,AddOn,printextension];
    print(printype,nom_de_g);
end

% ***********************************************************************
% Now plot groups, observations and variables
%%%%
nfig=nfig+1;figure(nfig);clf
ze_tR=[ze_title,' Groups & Observations.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
plotxyha([f_obs;fi],1,2,titre,[nom_r';nom_cat']);
axis(les_axes);axis('equal')

%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% All together now %%%%%%%%%%%%%%
%%%%
nfig=nfig+1;figure(nfig);clf
ze_tR=[ze_title,'Groups/Obs/Var.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
plotxyha([fj;f_obs;fi],1,2,titre,[nom_c';nom_r';nom_cat']);
axis(les_axes);axis('equal')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

AddOn=['Blocks'];
% Print the graph if asked for 
if imp==1;
    nom_de_g=[gen_name,AddOn,printextension];
    print(printype,nom_de_g);
end


