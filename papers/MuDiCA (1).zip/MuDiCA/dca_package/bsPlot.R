#bsPlot <- function(fboots,cpsu,catcher,axis1,axis2,minMaxList,interval=0.95,showEllipse=1,showPoints=0,main="",sub="",xlab="",ylab="",num_comparisons=0){
bsPlot <- function(fboots,cpsu,catcher,axis1,axis2,minMaxList,showEllipse=0.95,showPoints=0,main="",sub="",xlab="",ylab="",num_comparisons=0){

	plotCatcher = catcher
	minx = minMaxList$minx
	miny = minMaxList$miny
	maxx = minMaxList$maxx
	maxy = minMaxList$maxy

	dev.new()
	#plot(NULL,ylim=c(miny,maxy),xlim=c(minx,maxx),pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]),type='l',pos=0,main=main,sub=sub,xlab=xlab,ylab=ylab)
	plot(NULL,ylim=c(miny,maxy),xlim=c(minx,maxx),pos=0,main=main,sub=sub,xlab=xlab,ylab=ylab)
	
	for(i in 1:dim(cpsu$uc)[1]){
		groupBootBarys <- matrix(0,0,dim(fboots)[2])
		for(j in 1:dim(fboots)[3]){
			groupBootBarys <- rbind(groupBootBarys,fboots[i,,j])
		}
		corMat <- cor(groupBootBarys[,axis1],groupBootBarys[,axis2])
		scalex = sd(groupBootBarys[,axis1])
		scaley = sd(groupBootBarys[,axis2])
		groupBootBarysBary <- colMeans(groupBootBarys)


		if(showEllipse > 0){
			if(num_comparisons > 1){
				properInterval <- SidakCorrection((1-showEllipse),num_comparisons)
				properInterval = 1-properInterval			
			}else{
				properInterval <- showEllipse
			}
			ellOut <- PCAEllipse_BigN(cbind(groupBootBarys[,axis1],groupBootBarys[,axis2]),interval=properInterval)
		}
		
		if(showEllipse > 0){
			points(ellOut,pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]),type='l')
		}
		if(showPoints == 1){
			#points(groupBootBarys,pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]))
			points(groupBootBarys[,axis1],groupBootBarys[,axis2],pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]))				
		}

		if(showEllipse > 0){
			points(ellOut,pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]),type='l')
			#plot(ellOut,ylim=c(miny,maxy),xlim=c(minx,maxx),pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]),type='l',pos=0,main=main,sub=sub,xlab=xlab,ylab=ylab)
		}
		if(showPoints == 1){
			#points(groupBootBarys,pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]))
			points(groupBootBarys[,axis1],groupBootBarys[,axis2],pch=as.numeric(cpsu$cps[,2]),col=as.numeric(cpsu$cps[i,1]))				
		}
	}
}