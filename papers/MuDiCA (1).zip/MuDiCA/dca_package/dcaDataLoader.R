dcaDataLoader <- function(data_mat,group_mat,block_mat=0,sup_mat=0,vars=TRUE,file_mat_flag=1){
	
	
#X is the same X as DCA appendix. This is the data matrix.
#Y is the same Y as DCA appendix. This is the group matrix (i.e. which wine it is - defiend by a group of rows)
#Z is the same Z as DCA appendix. This is the block matrix (i.e. which participant - defined by a block of columns)
	
	if(file_mat_flag == 1){

		X = as.matrix(read.table(data_mat,sep=",",dec=".",header=vars, strip.white=TRUE))
		Y = as.matrix(read.table(group_mat,sep=",",dec=".",header=vars, strip.white=TRUE))
		if(block_mat == 0){
			#Z = diag(1,dim(X)[2])
			Z = matrix(1,1,dim(X)[2])
		}else{
			Z = as.matrix(read.table(block_mat,sep=",",dec=".",header=vars, strip.white=TRUE))		
		}
		
		if(sup_mat != 0){
			sup = as.matrix(read.table(sup_mat,sep=",",dec=".",header=vars, strip.white=TRUE))		
		}	
	}else{
		#print("An existing matrix was selected");
		X = as.matrix(data_mat)
		Y = as.matrix(group_mat)
		if(block_mat == 0){
			#Z = diag(1,dim(X)[2])
			Z = matrix(1,1,dim(x)[2])
		}else{
			Z = as.matrix(block_mat)
		}
		
		if(sup_mat != 0){
			sup = as.matrix(sup_mat)
		}
	}

	if(sup_mat != 0){
		return(list(x=X,y=Y,z=Z,s=sup))
	}
	return(list(x=X,y=Y,z=Z))
}