This set of files implements
Multi-Block Disscirminant Correspondence Analysis (MUDICA)
as described in (the Appendix of)
 Williams, L.J., Abdi, H., French, R., & Orange, J.B. (2010).
 A tutorial on Multi-Block Discriminant Correspondence Analysis 
 (MUDICA): A new method foranalyzing discourse data from clinical populations.
 Journal of Speech Language and Hearing Research, 53.
 Preprint available from 
 http://www.utdallas.edu/~herve/abdi-wafo2010-mudica-inpress.pdf.

 Written by Herve Abdi. herve@utdallas.edu www.utdallas.edu
         with help from Joseph Dunlop for drawing ellipses
 Usual caveats apply. These programs ae provided without guarantee.

 These programs are

Main File
 MUDICA_Example.m  
   % batch programs: enter the data and call the other programs
Computing Files
 DCA_pred.m
   % function: computes the DICA (with predicted values for the observations)
 BootDCABal.m
   % function: computes the bootstrap cnfidence intervals
 R2PermOnFactors.m
   % function: computes R2 and p-values
 MultiBlockDICA.m
   % function: computes the projectionsfor the Blocks
Graphic routines
 PlotEllipses4DCA
 PlotPrettyBootStrap
 PlotRowBADA
 PlotUglyBlocks


Look at the help for all these programs to know more.