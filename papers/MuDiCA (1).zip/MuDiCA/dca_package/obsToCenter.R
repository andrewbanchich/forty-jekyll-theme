#########################################################################################
# Stolen from Dr. Abdi DCA_pred.m
# Compute the distance matrix between observations and centers.
#########################################################################################
obsToCenter <- function(class_matrix,obs,i=0){
	
	if(length(i) > 1){
		Dsup = fastEucCalc(obs,i)
	}else{
		Dsup = obs
	}
	minD=apply(Dsup,1,min)
	Group_Assigned=Re(Dsup==repmat(minD,1,ncol(class_matrix)))
	return(list(sup=Dsup,assigned=Group_Assigned,confusion=t(Group_Assigned) %*% class_matrix))
}