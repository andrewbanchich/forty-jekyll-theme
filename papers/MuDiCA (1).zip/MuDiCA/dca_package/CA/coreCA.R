coreCA <- function(X,k=0,fix_eigens=FALSE,mRP=NULL,symmetric=TRUE){
	
	
	X_dimensions = dim(X)
	
	grandTotal = sum(X)
	colTotal = colSums(X)
	rowTotal = rowSums(X)

	if(is.null(mRP)){
		mRP<-makeRowProfiles(X,X_dimensions,colTotal,rowTotal,grandTotal)
		rowCenter = mRP$rowCenter
		masses = mRP$masses
		M = mRP$M
		weights = mRP$weights
		W = mRP$W
		rowProfiles = mRP$rowProfiles
		deviations = mRP$deviations
		mwDeviations = mRP$mwDeviations
	}

	pcaFIN <- basePCA(mwDeviations,k)
	pcaFIN$p = (diag(masses^(-1/2))) %*% pcaFIN$p
	pcaFIN$q = (diag(weights^(-1/2))) %*% pcaFIN$q
	
	if(fix_eigens){
		numberVariables = sum(X[1,]>=1)
		print(numberVariables)
		eigvals = pcaFIN$Dv^2
		new_eigs = eigenfix(eigvals,numberVariables)
		pcaFIN$Dv = new_eigs^(1/2)
		pcaFIN$Dd=diag(pcaFIN$Dv)
		pcaFIN$ng=length(pcaFIN$Dv)		
		pcaFIN$p=pcaFIN$p[,1:pcaFIN$ng]
		pcaFIN$q=pcaFIN$q[,1:pcaFIN$ng]		
	}
	taus = (pcaFIN$Dv^2/sum(pcaFIN$Dv^2))*100
	
	#Rows, F
	fi = pcaFIN$p %*% pcaFIN$Dd
	rownames(fi) <- rownames(X)	
	di = rowSums(fi^2)
	ri = repmat((1/di),1,pcaFIN$ng) * (fi^2)
	ci = repmat(masses,1,pcaFIN$ng) * (fi^2)/repmat(t(pcaFIN$Dv^2),X_dimensions[1],1)
	di = as.matrix(di)

	#Columns, G
	if(symmetric){
		fj = W %*% pcaFIN$q %*% pcaFIN$Dd
	}else{
		fj = W %*% pcaFIN$q
	}
	rownames(fj) <- colnames(X)
	dj = rowSums(fj^2)
	rj = repmat((1/dj),1,pcaFIN$ng) * (fj^2)
	cj = repmat(rowCenter,1,pcaFIN$ng) * (fj^2)/repmat(t(pcaFIN$Dv^2),X_dimensions[2],1)
	dj = as.matrix(dj)
	
	return(list(fi=fi,di=di,ci=ci,ri=ri,fj=fj,cj=cj,rj=rj,dj=dj,t=taus,M=M,W=W,pdq=pcaFIN))
}


# a generalized function for fixing eigenvalues for MCA

eigenfix <- function(eigvals,num_variables){
	
	#from original eigen values, eliminate all those that fall below the threshold
	#our threshold is 1/the number of variables we are analyzing
	new_eigvals <- eigvals[eigvals > (1/num_variables)]
	
	#fix the eigenvalues
	new_eigvals <- (num_variables/(num_variables-1))^2 * (new_eigvals -(1/num_variables))^2	
	return(new_eigvals[new_eigvals > (2*.Machine$double.eps)])
	
}

#so I can do some wizardry later!
makeRowProfiles <- function(X,X_dimensions,colTotal,rowTotal,grandTotal){
	rowCenter = colTotal/grandTotal
	masses = rowTotal/grandTotal
	M = diag(masses)
	weights = rowCenter^-1
	W = diag(weights)
	rowProfiles = diag(as.vector((X %*% repmat(1,X_dimensions[2],1))^-1)) %*% X
	deviations = rowProfiles - (repmat(1,X_dimensions[1],1)%*%rowCenter)
	mwDeviations = (M^(1/2)) %*% deviations %*% (W^(1/2))
	return(list(rowCenter=rowCenter,masses=masses,M=M,weights=weights,W=W,rowProfiles=rowProfiles,deviations=deviations,mwDeviations=mwDeviations))
}
