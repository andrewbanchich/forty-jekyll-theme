#########################################################################################
# Bootstrap function, based on BootDCABal.m, by Dr. Abdi 
#########################################################################################
bootstrap <- function(in_data,groups,F,eigenvalues,boot_sample,group_pop_resample=1){

	nfact=ncol(F)
	nc=ncol(groups)
	nI=nrow(in_data)
	Fboot=array(0,dim=c(nc, nfact, boot_sample))
	npg=colSums(groups)
	

	if(group_pop_resample){ 
		#Resample by defined groups.
		print('Begin Bootstrapping')
		pb <- txtProgressBar(1,boot_sample,1,style=1)
		for(i in 1:boot_sample){
			ret_BootSample <- buildBootSample(in_data,nc,groups)
			ret_SupObs <- supplementaryObservationPoints(eigenvalues,ret_BootSample$xsumboot,F)
			Fboot[,,i] <- ret_SupObs$sup
			setTxtProgressBar(pb,i)			
		}
	}else{
		#Resample by entire population - who cares about the groups?
		#This can be done later.
	}
	print('End Bootstrapping')
	return(list(fboot=Fboot))

}

#########################################################################################
# This function does the resampling of indices with no bias.
#########################################################################################
buildBootSample <- function(in_data,iters,groups){
	#Current method is modeled after BootDCABal.m by Dr. Abdi
	XBoot <- matrix(0,nrow(in_data),ncol(in_data))
	boot_indices <- matrix(0,nrow(in_data),1)
	for(i in 1:iters){
		#currently a shorter version than BootDCABal
		#This could be a lot shorter, if using some magic computer trickery!
		indices = as.matrix(which(groups[,i] == 1))
		number_of_resamples = dim(indices)[1]
		#update with defaults to be overridden...
		boot_indices_per_group <- sample_selection(indices,number_of_resamples)
		boot_indices[indices,] <- boot_indices_per_group
		XBoot[indices,] = in_data[boot_indices_per_group,]
	}
	return(list(xboot=XBoot,xsumboot=t(groups)%*%XBoot,bi=boot_indices))
}

#########################################################################################
# This function does the resampling of indices with no bias.
# This can be shortened. The ifs are overkill.
#########################################################################################
sample_selection <- function(selection_range,resample_size,replacement=0,method=0){

	if(replacement){
		#effectively, a reordering.
		return(sample(selection_range,resample_size,FALSE))
	}else{
		#These do the same (conceptually).
		if(method){
			return(ceiling(runif(selection_range,0,resample_size)))
		}
		#this is the default
		return(sample(selection_range,resample_size,TRUE))
	}
}