source("MuDICA/dca_package/Visualizers/prettyGraphs.R")
source("MuDICA/dca_package/Visualizers/prettyGraphsHelpers.R")
source("MuDICA/dca_package/Visualizers/minmaxHelperV.R")