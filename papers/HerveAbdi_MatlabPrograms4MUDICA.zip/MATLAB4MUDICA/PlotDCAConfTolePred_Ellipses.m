%****************************************************************
% PlotDCAEllipses
% Plot the Bootstraped Ellipses for a DCA
%****************************************************************
% 4 The plots.
%   To be rewritten as a script/function
%
% Needs
% F: Factor scores for I set set
% njuges: Number for judges (i.e., # of distance matrices
% LeRF: a nbeers*nfactors*njuges array
%       # factor scores for each juge
% Fact4Words: Coordinates of the words
% le_vocabulaire: the words themselves

NoVoc=1;
printfigure=imp;
% printfigure=1 -> print the figure
% Need a file name
%

if exist('NoVoc')==0;NoVoc=1;end
% Check if nfig exist if not create it
if exist('nfig')==0;
 nfig=0;
end
ax1=axis_horizontal;
ax2=axis_vertical;
% specify the axes of interest
%
% First get min and max for correct scaling
% of the compromise plots


% 1. plot the bootstrap here
%
% color for printing

 code_couleur=['r','m','y','b','g','c','k'];
 LesCouleurs=['b','g','c','r','m','y']';
%  LesCouleurs=CouleurVin;

% PlotZeBootStrapV2
%
% Script Plot the bootstrap
%
% here  I convert the parameter of DCA
% to match the parameter of the ellipse program from DISTATIS
% PS -> Herve this is Beurk Programming
%
% nc is # of groups for the DCA
%
nbeers=nc;
% tc is percentage of Inertia
%
tc=round(t);
lc=round(lambda);
% F is the coordinates of the groups
F=fi;
%
for nn=1:nc;
 Nom_de_row{nn}=char(nom_cat{1,nn});
end
 

% Go for Confidence Ellipsoids on Bootstrap
%
% Confidence ellipsoid
% Plot  them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
%le_petit=min(squeeze(min(LeRF(:,:,:)))');
%le_grand=max(squeeze(max(LeRF(:,:,:)))');
le_petit=min(squeeze(min(FBoot(:,:,:)))');
le_grand=max(squeeze(max(FBoot(:,:,:)))');


p=[le_grand(1)-le_petit(1)]/10;
%le_petit=min([f_obs]);
%le_grand=max([f_obs]);
les_axesEl=[le_petit(ax1)-2*p,le_grand(ax1)+2*p,...
            le_petit(ax2)-2*p,le_grand(ax2)+2*p];
        All_F=[fi;fj;f_obs;f_obs_pred];
minc=min(All_F);
maxc=max(All_F);
percent_of_inertia=100*lambda./sum(lambda);
p=[maxc(1)-minc(1)]/30;

les_axes=[minc(ax1)-p,maxc(ax1)+p,...
          minc(ax2)-p,maxc(ax2)+p]; 
les_axesEl=les_axes;    
% Bad Fix for ALW here
% Here we force the value of les_axes to be equal
% to the value used by PlotDCAEllipses_ALW
% this makes both set of graphs plotted with the same
% scale. 
%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_title='DCA ';
ze_tRC=[ze_title,' Confidence Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);

for k=1:ncp;
    %debut=(k-1)*npieces+1;
    %fin=debut+npieces-1;
    %partip_scores=f_obs(debut:fin,:);
    BootConf=squeeze(FBoot(k,:,:))';
    %truc=char(nom_cat{k});
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),BootConf(:,[ax1,ax2]),...
    code_couleur(k),truc(1))    
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='ConfElli';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end

% New version ChiChi
% Plot Pretty Ellipses
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% le_petit=min(squeeze(min(FBoot(:,:,:)))');
% le_grand=max(squeeze(max(FBoot(:,:,:)))');
% p=[le_grand(1)-le_petit(1)]/10;
% les_axesEl=[le_petit(ax1)-2*p,le_grand(ax1)+2*p,...
%             le_petit(ax2)-2*p,le_grand(ax2)+2*p];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Mean Confidence Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    BootConf=squeeze(FBoot(k,:,:))';
    truc=char(Nom_de_row(1,k)); % Use the one letter name
    PlotEllipse(F(k,[ax1,ax2]),BootConf(:,[ax1,ax2]),...
        code_couleur(k),truc(1))
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lc(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lc(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='ConfElli2';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end


%
% PLot the tolerance intervals here
% First the standard ones
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
% 
nfig=nfig+1;
figure(nfig);clf;
tolevel=.95; % tolerance interval level
ze_title='DCA ';
ze_tRC=[ze_title,' Tolerance Interval (',int2str(tolevel*100),'%) '];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    %
    Fobs4plot=f_obs(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1,ax2]),...
    code_couleur(k),truc(1))    ;
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='TolElli';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end


% now the editable ones
% 
nfig=nfig+1;
figure(nfig);clf;

ze_tRC=[ze_title,' Tolerance Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    Fobs4plot=f_obs(Y==k,:);
    Fobs4plot=f_obs(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=char(Nom_de_row(1,k));
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1:ax2]),...
    code_couleur(k),truc(1)) ;
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lc(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lc(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='TolElli2';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end


% ******************************************************************
%
% PLot the prediction intervals here
% First the standard ones
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
% 
nfig=nfig+1;
figure(nfig);clf;
tolevel=.95; % tolerance interval level
ze_title='DCA ';
ze_tRC=[ze_title,'Prediction Interval (',int2str(tolevel*100),'%) '];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    %
    Fobs4plot=f_obs_pred(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1,ax2]),...
    code_couleur(k),truc(1))    ;
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='PredElli';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end


% now the editable ones
% 
nfig=nfig+1;
figure(nfig);clf;

ze_tRC=[ze_title,' Prediction Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    Fobs4plot=f_obs_pred(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=char(Nom_de_row(1,k));
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1:ax2]),...
    code_couleur(k),truc(1)) ;
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lc(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lc(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='PredElli2';
    print(printype,[gen_name,'_',nom_de_print,'.',printextension])
end




