#########################################################################################
#	Plot fixed or random effect.
# It is just plotting points and drawing circles...
#########################################################################################

dcaPlot <- function(cpsu,axis1=1,axis2=2,classes,fj,fobs,lambda,minMaxList,catcher=FALSE,plot_ellipses=0.95,plot_centers=1,plot_points=1,main="",sub="",xlab="",ylab=""){
	cps = cpsu$cps
	uniqueClasses = as.matrix(cpsu$uc)
	
	dev.new()
	if(plot_ellipses != 0){
		ellipsePlotter(fobs,fj,cps,axis1,axis2,classes,uniqueClasses,minMaxList,interval=plot_ellipses,main=main,sub=sub,xlab=xlab,ylab=ylab)
		#a necessary override occurs here.
		plotHelper(fobs,fj,cps,axis1,axis2,classes,uniqueClasses,TRUE,plot_points,plot_centers,minMaxList,main,sub,xlab,ylab)
	}else{
		plotHelper(fobs,fj,cps,axis1,axis2,classes,uniqueClasses,catcher,plot_points,plot_centers,minMaxList,main,sub,xlab,ylab)
	}
}

plotHelper <- function(fobs,fj,cps,axis1,axis2,classes,uniqueClasses,catcher,plot_points,plot_centers,minMaxList,main,sub,xlab,ylab){
	
	if(plot_points){
		dataPlotter(fobs,cps,axis1,axis2,classes,uniqueClasses,minMaxList,catcher,m=main,s=sub,xl=xlab,yl=ylab)
		catcher=TRUE
	}
	if(plot_centers){
		dataPlotter(fj,cps,axis1,axis2,uniqueClasses,uniqueClasses,minMaxList,catcher,1,m=main,s=sub,textorpoint=1,xl=xlab,yl=ylab)
	}

}