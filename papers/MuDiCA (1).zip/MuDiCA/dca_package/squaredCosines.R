#########################################################################################
# Calculate the squared cosines of observations
#
#########################################################################################

squaredCosines <-function(lambda,f_obs){
	n_eigen=length(lambda)
	fo2=f_obs^2
	d_obs=rowSums(fo2)
	c_obs=fo2/repmat(d_obs,1,n_eigen)
	
	return(list(fo2=fo2,d_obs=d_obs,c_obs=c_obs))
}