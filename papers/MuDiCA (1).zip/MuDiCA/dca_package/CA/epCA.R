epCA <- function(X,k=0){
	return(coreCA(X,k))
}
