#########################################################################################
# This is JACKKNIFING!
#########################################################################################
jkDCA <- function(X,Y,Z,DCAdata)
{
	num_obs <- nrow(X)
	num_vars <- ncol(X)

	fixed_fj = DCAdata$f
	fixed_fi = DCAdata$g
	fixed_lambda = DCAdata$l
	
	fi_sup_matrix = matrix(0,num_obs,length(fixed_lambda))
	Dsup = matrix(0,num_obs,ncol(Y))
	fi_jack <- array(0,dim=c(ncol(Y), length(fixed_lambda), nrow(Y)))
	f_obs_pred <- matrix(0,num_obs,length(fixed_lambda))
	
	for (i in 1:num_obs){
		XSumMinus = t(Y[-i,]) %*% X[-i,]
		pre_fi_jack <- supplementaryObservationPoints(fixed_lambda,XSumMinus,fixed_fj);
		fi_jack[,,i] <- pre_fi_jack$sup
		
		ret_DCA <- dca(X[-i,],Y[-i,],Z[-i,])
		F = ret_DCA$f
		G = ret_DCA$g
		l = ret_DCA$l
		w = t(as.matrix(ret_DCA$w))
		
		ret_Sup <- supplementaryObservationPoints(l,t(as.matrix(X[i,])),F)
		fi_sup = ret_Sup$sup
		profile = ret_Sup$profile
		deltainv = ret_Sup$i
					
		fi_sup_matrix[i,] <- fi_sup
		Dsup[i,] <- fastEucCalc(fi_sup,G)		
		li <- X[i,]/sum(X[i,])
		
		nLi=length(l)
		f_obs_pred[i,] <- ((li %*% (F * repmat(t(l^(-1)),nrow(fixed_fj),1)))) %*% (t(F) * repmat(1/w,nLi,1)) %*% (fixed_fj * repmat(t(fixed_lambda^(-1/2)),nrow(fixed_fj),1))
		
	}
	assignments <- obsToCenter(Y,Dsup)
	Dsup <- assignments$sup
	assigned <- assignments$assigned
	confusion  <- assignments$confusion
	
	return(list(sup=Dsup,assign=assigned,conf=confusion,fobspred=f_obs_pred))
}