source("MuDICA/dca_package/MUDICA_DEMO.R")
source("MuDICA/dca_package/dcaDataLoader.R")
source("MuDICA/dca_package/jkDCA.R")
source("MuDICA/dca_package/dca.R")
source("MuDICA/dca_package/grandTotal.R")
source("MuDICA/dca_package/obsToCenter.R")
source("MuDICA/dca_package/MatLabFuncs.R")
source("MuDICA/dca_package/fastEucCalc.R")
source("MuDICA/dca_package/supplementaryObservationPoints.R")
source("MuDICA/dca_package/squaredCosines.R")
source("MuDICA/dca_package/bootstrap.R")
source("MuDICA/dca_package/dcaPlot.R")
source("MuDICA/dca_package/dataPlotter.R")
source("MuDICA/dca_package/colorPoints.R")
source("MuDICA/dca_package/ellipsePlotter.R")
source("MuDICA/dca_package/jkPlot.R")
source("MuDICA/dca_package/bsPlot.R")
source("MuDICA/dca_package/varPlotter.R")
source("MuDICA/dca_package/R2Test.R")


#Load CA
source("MuDICA/dca_package/CA/staticCALoad.R")

#Load BASE
source("MuDICA/dca_package/BASE/staticBASELoad.R")

#Load other visualizers
source("MuDICA/dca_package/Visualizers/staticVisualizersLoad.R")