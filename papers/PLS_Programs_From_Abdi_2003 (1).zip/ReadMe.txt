This set of MATLAB programs show
an example of a PLS regression.
The example is taken from the
introductory paper:
Abdi, H., (2003).
Abdi, H. (2003). Partial least squares regression (PLS-regression). 
In M. Lewis-Beck, A. Bryman, T. Futing (Eds): 
Encyclopedia for research methods for the social sciences. 
Thousand Oaks (CA): Sage. 

This paper as well as these programs are 
available form the author's home page:


http://www.utdallas.edu/~herve/

There are 3 programs:

example_pls.m
PLS_nipals.m
plotxyha.m

1. example_pls.m
   Input the data and call the other
   programs. THis is the program you will
   need to change if you want to use PLS.
   I have tried to comment the program 
   well enough to make this easy.


2. PLS_nipals.m
   This program is a plain and
   not very efficient implementation 
   of the standard pls nipals algorithm.
   use the help to see how to call it.


3. plotxyha.m
   is a routine to plot graph
   with names. 
   The graph of Abdi (2003)
   were made with this routine.



Please see the original paper for explanation
of the results and output.

As usual, these programs were written for
educational purposes and are provided
without any guarantee of any kind
(except that the author has tried his best
to make them clear and easy to use).

