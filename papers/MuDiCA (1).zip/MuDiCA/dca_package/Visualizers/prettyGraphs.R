#V1 - no ellipses, yet.
#DEPENDS ON:
	#minMaxHelper
	#colorPoints
prettyGraphs <- function(data_matrix,color_vector=NULL,display_names=FALSE,x_axis=1,y_axis=2,new_window=TRUE,x_label="",y_label="",main_label="",axis_line_width=3){
	
	#I need a different type of checker here...
	#Also, I need to use apply instead of my silly matrix nonsense below. See how FactoMineR does it.
	if(is.null(color_vector)){
		design_matrix <- diag(dim(data_matrix)[1])
		colnames(design_matrix) <- rownames(data_matrix)
		rownames(design_matrix) <- rownames(data_matrix)
		color_vector <- createColorVectors(design_matrix)
	}
	
	#minmaxHelper should inflate the min and max prior to getting here.
	min_max_list <- minmaxHelperV(data_matrix,data_matrix,x_axis,y_axis)
	axis_list <- determineAxesPosition(min_max_list)
	if(new_window==TRUE){
		makeNewPlotWindow(axis_list,min_max_list,x_label,y_label,main_label,axis_line_width)
	}
	
	if(display_names==TRUE){
		plotText(data_matrix,color_vector,x_axis,y_axis)
	}else{
		plotPoints(data_matrix,color_vector,x_axis,y_axis)
	}

}

plotPoints <- function(data_matrix,color_vector,x_axis=1,y_axis=2){
	points(data_matrix[,x_axis],data_matrix[,y_axis],col="black",pch=21)
	points(data_matrix[,x_axis],data_matrix[,y_axis],col=color_vector,pch=20)		
}

plotText <- function(data_matrix,color_vector,x_axis=1,y_axis=2){
	text(data_matrix[,x_axis],data_matrix[,y_axis],col=color_vector,labels=rownames(data_matrix),cex=0.8,pos=3)
}