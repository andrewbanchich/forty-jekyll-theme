SidakCorrection <- function(alpha,num_comparisons){
	
	return( 1-((1-alpha)^(1/num_comparisons)) )
	
}