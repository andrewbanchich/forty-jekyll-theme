#########################################################################################
# This function gets the grand total of the matrix.
#
#########################################################################################
grandTotal <- function(some_matrix,style_flag=1){
	if(style_flag == 1){
#using matrix algebra, we maintain that this is returned in a [1,1] matrix.
		return(t(matrix(1,nrow(some_matrix),1)) %*% some_matrix %*% matrix(1,ncol(some_matrix),1))
	}else{
#using a summation, we just get a scalar value back.
		return(sum(some_matrix))
	}
	
}