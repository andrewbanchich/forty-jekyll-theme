#########################################################################################
# afc_sup function.
# For calculating the supplementary points.
# l = fixed effect lambda
# X = "supplementary" points
# F = F (from chapter), these are scores.
#########################################################################################
supplementaryObservationPoints <- function(l,X,F){

#From afc_sup.m:
	inv_delta=l^(-1/2)
	if(nrow(X) == 1){
		sumVal = sum(X)
	}else{
		sumVal = rowSums(X)
	}
	#L from the chapter - computed differently
	profile=X/((sumVal)%*%matrix(1,1,nrow(F)) )
	#f_sup is H from the chapter?
	f_sup = profile %*% F %*% diag(inv_delta)
	return(list(i=inv_delta,p=profile,sup=f_sup))
}