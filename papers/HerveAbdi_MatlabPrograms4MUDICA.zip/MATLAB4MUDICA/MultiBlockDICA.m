function  [BlockFactor]=MultiBlockDICA(X,G,Tnum,fj,lambda);
%USAGE  [BlockFactor]=MultiBlockDICA(X,G,Tnum,fj,lambda);
% Compute the coordinates of the projections
% of subtables for  MUDICA 
% (MUltiblock Discriminant Analysis)
%  This routine is called _after_ the call
%  to the DICA program (e.g. DCA_pred) 
%
%
% need Tnum Block indicator matrix
% X: the original data matrix
% G: The indicator matrix
% fj: the columns DICA coordinates
%

% Get the profiles 
Xsum=G'*X;
R_Xsum=Xsum./repmat(sum(Xsum,2),1,size(Xsum,2));
% Weigths (columns)
w=sum(sum(Xsum))./sum(Xsum);
% Masses (rows)
masses=sum(Xsum,2)./sum(sum(Xsum));
% How many subtables?
nK=max(Tnum);
% nK is the number of subtables


for k=1:nK;
  Lindex=Tnum==k;
  wYk=(sum(w)./sum(w(Lindex)));
  fimk=(wYk)*R_Xsum(:,Lindex)...
              *fj(Lindex,:)*diag(lambda.^(-1/2));
   BlockFactor{k}.fi=fimk;
   BlockFactor{k}.fk=sum(fimk.*repmat(masses,1,size(fimk,2)));
end

return

k=1;



Lindex=Tnum==k;
wY1=(sum(w)./sum(w(Lindex)));
fim1=(wY1)*R_Xsum(:,Lindex)*fj(Lindex,:)*diag(lambda.^(-1/2));


k=2;
% wY2=nJ/nJ2;
Lindex=Tnum==k;
wY2=(sum(w)./sum(w(Lindex)));
fim2=(wY2)*R_Xsum(:,Lindex)*fj(Lindex,:)*diag(lambda.^(-1/2));


 % computed as barycenters
masses=sum(Xsum,2)./sum(sum(Xsum));
% Coordinates of the tables
fiK= ...
[sum(fim1.*repmat(masses,1,size(fim1,2)))
sum(fim2.*repmat(masses,1,size(fim2,2)))];

return


% Work on the subtables from here
%
be=1;fin=nJ1;
be2=nJ1+1;fin2=nJ1+nJ2;

Tnum=[ones(1,nJ1),2*ones(1,nJ2)];
% Indicator vector column j = subtable number



%% Compute the "summed table"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Xsum=G'*X;
% %
% nJ1=size(Y1,2);nJ2=size(Y2,2);nJ3=size(Y3,2);
w=sum(sum(Xsum))./sum(Xsum);


% old code 
% wY1=nJ/nJ1; <- works for MCA but not for simple CA
wY1=(sum(w)./sum(w(be:fin)));
fim1=(wY1)*R_Xsum(:,be:fin)*fj(be:fin,:)*diag(lambda.^(-1/2));
% fim1=nK*R_X(:,be:fi)*fjm(be:fi,:)*diag(lambd.^(-1/2));

% wY2=nJ/nJ2;
wY2=(sum(w)./sum(w(be:fin)));
fim2=(wY2)*R_Xsum(:,be:fin)*fj(be:fin,:)*diag(lambda.^(-1/2));
%
% Barycentric projection when the masses are the inverse of the weights
% Note
test_proj= (1/wY1)*fim1 + (1/wY2)*fim2;
%be=nJ1+nJ2+1;fi=nJ1+nJ2+nJ3;
%fim3=(nJ/nJ3)*R_X(:,be:fi)*fjm(be:fi,:)*diag(lambd.^(-1/2));
 %
 % Additional idea. to Project the whole table
 % computed as barycenters
masses=sum(Xsum,2)./sum(sum(Xsum));
% Coordinates of the tables
fiK= ...
[sum(fim1.*repmat(masses,1,size(fim1,2)))
sum(fim2.*repmat(masses,1,size(fim2,2)))];

