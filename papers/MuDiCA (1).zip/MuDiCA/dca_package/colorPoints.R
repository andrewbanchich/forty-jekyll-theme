#########################################################################################	
# TODO: This function could benefit BIG TIME from performing a distance calculation on RGB colors
# to make sure they are a minimum distance away from one another during selection! This would be 
# able to utilize fastEucCalc, which will be a part of the DCA package, anyways.
#
# This function performs some magic in order to get a LARGE list of colors to randomly select from
# while having NO repeats for the number of classes selected. However, a lot of colors are similar.
# 
# If the maximum number of colors are selected, a new point style is then selected, effectively
# allowing us to recycle our colors, whilst maintaing a distinct representation of new classes!
#
# You would need ~400 classes in order to exceed all colors!
#########################################################################################	
colorPoints <- function(classes){


# Initialization in a stupid way for now, but it works.
	possibles = createOriginalPointsAndColors()
	possibleColors = possibles$colors
	possiblePoints = possibles$points
	
#This requires that classes are input either as a vector, or a matrix, where
#the observations are column wise, and unique elements can be retrieved by the
#rows, and then counted!
	uniqueClasses = unique(as.matrix(classes))
	numberOfClasses = dim(uniqueClasses)[1]

	colorPointStruct <- matrix(list(),numberOfClasses,2)
		
	thisPoint = sample(length(possiblePoints),1,FALSE)
	possiblePoints = possiblePoints[-thisPoint]
	thisColor = sample(length(possibleColors),1,FALSE)
	possibleColors = possibleColors[-thisColor]
	
	for(i in 1:numberOfClasses){
		if(length(possibleColors) >= 1){
			thisColor = (thisColor + 30) %% length(possibleColors)
			possibleColors = possibleColors[-thisColor]
		}
		else if(length(possiblePoints) >= 1){
			thisPoint = sample(length(possiblePoints),1,FALSE)
			possiblePoints = possiblePoints[-thisPoint]
			possibleColors = createOriginalColorList()
			thisColor = (thisColor + 30) %% length(possibleColors)
			possibleColors = possibleColors[-thisColor]
		}
		else{
			possibles = createOriginalPointsAndColors()
			possibleColors = possibles$colors
			possiblePoints = possibles$points
			thisPoint = sample(length(possiblePoints),1,FALSE)
			possiblePoints = possiblePoints[-thisPoint]		
			thisColor = (thisColor + 30) %% length(possibleColors)
			possibleColors = possibleColors[-thisColor]
		}
		colorPointStruct[i,] <- list(clr=thisColor,pt=thisPoint)
	}
	return(list(cps=colorPointStruct,uc=uniqueClasses))
}

createOriginalColorList <- function(){
	possibleColors = colors()
	possibleColors = possibleColors[-grep("white",possibleColors)]	
	possibleColors = possibleColors[-grep("black",possibleColors)]	
	possibleColors = possibleColors[-grep("snow",possibleColors)]
	possibleColors = possibleColors[-grep("ivory",possibleColors)]	
	possibleColors = possibleColors[-grep("azure",possibleColors)]
	possibleColors = possibleColors[-grep("gray",possibleColors)]
	possibleColors = possibleColors[-grep("grey",possibleColors)]
	possibleColors = possibleColors[-grep("seashell",possibleColors)]
	possibleColors = possibleColors[-grep("steel",possibleColors)]	
	possibleColors = possibleColors[-grep("light",possibleColors)]
	return(possibleColors)
}

createOriginalPointList <- function(){
	#this is dumb, but consistent.
	vals = 1:25
	vals = vals[-15]
	vals = vals[-15]
	vals = vals[-15]
	return(vals)
}

createOriginalPointsAndColors <- function(){
	return(list(colors=createOriginalColorList(),points=createOriginalPointList()))
}