function [nfig]=PlotPrettyBootstrap(fi,lambda,nom_cat,fi_boot,...
       f_obs,ze_title,nfig,graph_gen,imp,LesAxes,printype,printextension)
% USAGE [nfig]=PlotPrettyBootstrap (fi,lambda,nom_cat,fi_boot...
%       f_obs,ze_title,nfig,graph_gen,imp,LesAxes,printype,printextension)
% plot the froups for a BADA type of analysis
% Only the groups (fi) are plotted.
% The observations are there to insure that the scaling is correct
%
% fi:  coordinates of the groups to be ploted
% lamdda: eigenvalues
% nom_cat: names of the categories
% fi_boot= output from the Bootstrap program
% f_obse: the coordiantes of the categories
% ze_title: generic title
% nfig # of the figure (default=0)
% ze_title -> generic title
% imp -> a 0/1 variable 1-> we print
% nom_r -> name of the observations
% nom_cat -> name of the categories
% nom_rs -> nam of the supplemetary elements (if any)
% nI -> number of observations 
%   (if nI does not exit the script guesses from f_obs)
% Y: the 0/1 nI*ngroup indicator matrix
% fi -> coordinates of the categories
% fj -> coordinates of the variables
% f_obs -> coordinates of the observations
% f_isup -> coordinates of the supplementary observations
% axe_vertical and axe_horizontal [default are 2 and 1]
% printype      : type of graph (default "-depsc2")
% printextension: graph extension (default ".eps"
% ***************************************************************
% Output is nfig = number of the current figure
%
% ***************************************************************
% Current version February 16, 2010
% Herve Abdi. herve@utdallas.edu, www.utdallas.edu/~herve
%

% default 
if exist('LesAxes')==0;LesAxes=[1,2];end

if exist('graph_gen')==0;graph_gen='DICA_';end
if exist('ze_title')==0;ze_title='DICA ';end
if exist('printype')==0;printype='-depsc2';end
if exist('printextension')==0;printextension='.eps';end
% For printing -> can be changed
extprint=printextension;
niter=size(fi_boot,3);
nc=size(fi,1);
if exist('f_isup')~=1;
    f_isup=[];nom_rs=[];
end
% % 
if exist('nI')~=1;
    nI=size(f_obs,1);
end

axe_horizontal=LesAxes(1);
axe_vertical=LesAxes(2);
ax1=axe_horizontal;
ax2=axe_vertical;
code_couleur=['r','g','b','y','m','c','k']; 
maxcol=length(code_couleur);

%
% Make sure that we have the same 
% coordinates system for the rows and the columns
% 
All_F=[fi;f_obs];
minc=min(All_F);
maxc=max(All_F);
percent_of_inertia=100*lambda./sum(lambda);
p=[maxc(1)-minc(1)]/30;
les_axes=[minc(axe_horizontal)-p,maxc(axe_horizontal)+p,...
          minc(axe_vertical)-p,maxc(axe_vertical)+p];  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% Plot here 
% nfig=0;
if exist('nfig')~=1;nfig=0;end

nfig=nfig+1;figure(nfig);clf
% Get the axes right
le_petit=min([f_obs]);
le_grand=max([f_obs]);
les_axesEl=[le_petit(axe_horizontal)-5*p,le_grand(axe_horizontal)+5*p,...
            le_petit(axe_vertical)-5*p,le_grand(axe_vertical)+5*p];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Class Centers'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
 
% Plot empty names             
 nom_vide=cellstr(char(ones(nc,2)*32));           
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(fi,ax1,ax2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',3);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',3);
for k=1:nc;
    indcol=mod(k,maxcol);if indcol==0;indcol=maxcol;end
    text(fi(k,ax1),fi(k,ax2),char(nom_cat{k}),...
        'FontWeight','bold',...
        'FontSize',18,...
        'Color',code_couleur(indcol)),
end
if imp==1;
    nom_de_g=[graph_gen,'Center',extprint];
    print(printype,nom_de_g);
end
% Trickier here get the ellipsoids
% and plot them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
le_petit=min([f_obs]);
le_grand=max([f_obs]);
les_axesEl=[le_petit(axe_horizontal)-5*p,le_grand(axe_horizontal)+5*p,...
            le_petit(axe_vertical)-5*p,le_grand(axe_vertical)+5*p];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' 95% Mean Confidence Interval ',...
    '(N=',int2str(niter),')'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
 
% Plot empty names             
 nom_vide=cellstr(char(ones(nc,2)*32));           
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(fi,ax1,ax2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);

for k=1:nc;
    indcol=mod(k,maxcol);if indcol==0;indcol=maxcol;end
    %les_indices=find(Y(:,k)==1);
    %debut=(k-1)*npieces+1;
    %fin=debut+npieces-1;
    %partip_scores=f_obs(les_indices,[ax1,ax2]);
    partip_scores=squeeze(fi_boot(k,[ax1 ax2],:))';
    truc=char(nom_cat{k});
    %PlotClassEllipse(fi(k,[ax1,ax2]),partip_scores,code_couleur(k),truc(1))
    PlotClassEllipseOnly(fi(k,[ax1,ax2]),partip_scores,code_couleur(indcol),truc(1))
end
if imp==1;
    nom_de_g=[graph_gen,'ConfElli',extprint];
    print(printype,nom_de_g);
end
 

function PlotClassEllipseOnly(fi,scores,code_couleur,nom)
%USAGE PlotEllipseOnly(Fcenter,Felements,couleur,nom)
% Plot a category with center + confidence ellipsoid
% Fcenter=coordinate of the center of the category
% Felement=coordinates of the points
% with the center of the category as a name: nom
% Plotted with one colour: couleur (can be a vector)
% along with the 95% confidence interval
% Experimental version. 
% Herve Abdi October 2006
%            Last Modified: January 2007
% Uses draw_PCA_Ellipse from Joseph Dunlop

nopoint=1;
axe_horizontal=1;
axe_vertical=2;
[ns,nK]=size(scores);

text(fi(axe_horizontal),fi(axe_vertical),...
           nom,...
          'color',code_couleur,...
          'LineWidth',6,... 
          'FontSize',15,...
          'FontAngle','oblique',...
          'FontWeight','bold');
if  nopoint==0 ;   
    for j=1:ns;
    % text(partip_scores(j,1),...
    %      partip_scores(j,2),...
    %      char(nc_jack(k)));
     plot(scores(j,1),...
          scores(j,2),...
          'o',...
          'color',code_couleur,...
          'LineWidth',6,...
          'MarkerSize',6);
    end
end   
  [coords,q,x_length,y_length,center_xy2]=...
      draw_PCA_ellipse(scores,code_couleur);

  
  
% %%%%% Functions Here:
%  draw_PCA_ellipse, paq, disteucl2  
function [coords,q,x_length,y_length,center_xy2] = draw_PCA_ellipse(X,colour,width_ell)
% [coords,q,x_length,y_length,center_xy] =
% draw_PCA_ellipse_extra(X,colour,width_ell)
% draw_PCA_ellipse creates a containing ellipse for a set of points (X)
% the function centers and performs a pca on points (to get rotation)
% takes the outermost points of absolute value (convex hull)
% and generates an ellipse that just contains these points
% the ellipse is generated by determining the ratio of major/minor axes,
% the ellipse is scaled by the point most distant from the centroid
% according to this proportion
% once the major/minor axes sizes are determined, a set of poins to be
% graphed defining the ellipse is generated, rotated, recentered and
% returned
% overloaded options colour (color) and width define the color and
% pixel-width
% parameters for the ellipse, default is blue and 3 pixels
% returned parameters: 
% coords - coordinates of the polygon approximating the ellipse
% q - rotation matrix
% x-length, y-length - length major and minor axes respectively
% center_xy2 - barycenter of the 95% cloud of points
% note, this function depends on:
% disteucl2, paq 
% check # of args
%  Joseph Dunlop. October 19. 2006

if nargin == 1; colour = '-b'; width_ell = 3; end
if nargin == 2; width_ell = 3; end
% first we need to reduce the set of points to the 95% closest to the
% barycenter
[r,c] = size(X);
center_xy = sum(X,1)/r; % find the center
% determine the 95% closest points and remove the rest
dist_X = [disteucl2(X, center_xy) X];
C = sortrows(dist_X,1);
C((ceil(.95*r)+1):r,:) = []; % trim 95%
C(:,1)=[]; % trim the distances
% now we'll center the ellipse, then perform a pca, remaining work will
% be done from rotated coords
[r2,c2] = size(C);
center_xy2 = sum(C,1)/r2; 
% find the center
[p,a,q] = paq(C - ones(r2,1)*center_xy2);
% pca on the centered set of points
F = p*diag(a); 
% find the projections onto the new axes
% reduce to convex hull of the abs values of the points by adding
% max_x,max_y and origin points
F_temp = abs(F); % collapse to quadrant 2
F_temp = [F_temp; 0 0; max(F_temp(:,1)) 0; 0 max(F_temp(:,2))]; 
% 'complete' the rectangle
k = convhull(F_temp(:,1), F_temp(:,2)); 
% find the hull composed of the these points
junk = find(k >length(F));
k(find(k > length(F))) = [];
F_hull = abs(F(k,:));
% we'll use the proportion of interia along each axis (contained in 'a') as
% our proportion in determing the major/minor axis of the ellipse
c_1 = a(1)/a(2);
y_length = max(sqrt((F_hull(:,1).^2)./(c_1^2) + (F_hull(:,2).^2)));
x_length = y_length*c_1;
% we'll use these lengths to draw the ellipse
j = pi/64:pi/64:2*pi;
coords = [cos(j')*x_length sin(j')*y_length];
coords = coords*q' + ones(length(j),1)*center_xy2;
% rotate by cosines (q') and recenter to center of points (center_xy)
% plot the coords as an ellipse
plot([coords(:,1);coords(1,1)],...
    [coords(:,2);coords(1,2)],...
    colour, 'LineWidth',width_ell);

function [P,a,Q]=paq(X,k);
%USAGE [P,a,Q]=paq(X,k);
% k-Singular value decomposition of the I by J matrix X
%if k is not present then k=min{I,J}
%if k is larger larger than min{I,J} then k= min
%if k is larger than K=the actual number 
%        of singular values, then k=K
% the singular vectors and values are ordered
% in decreasing order
% P are the eigenvectors of X'X
% Q are the eigenvector of XX'
% a is the vector of the SINGULAR values
% NOTE that a = sqrt(lambda)
% where lambda are the eigenvalues of both X'X and XX'
%% Herve Abdi. October 2004 (revised version)
% 
   epsilon=2*eps;
%  tolerance to be considered 0 for an eigenvalue
[I,J]=size(X);
m=min(I,J); 
if nargin==1, k=m;
        else if k > m, k=m;end;
     end;
flip=0; 
if I < J, X=X';flip=1;end;
% Incorporate eigen routine here %%%%%
  [Q,l]=eig(X'*X);
  l=diag(l);
  [l,k2]=sort(l);
  n=length(k2);
  l=l((n+1)-(1:n));
  Q=Q(:,k2((n+1)-(1:n)));
% keep the non-zero eigen value only (tolerance=epsilon)
  pos=find(any([l';l'] > epsilon ));
  l=l(pos);
  Q=Q(1:n,pos);
 %%%%%% End of Eigen %%%%%%%%%%%%%%%%%
ll= max(size(l)); if k > ll, k=length(l);end;
Q=Q(:,1:k);
l=l(1:k);
a=sqrt(l);
[niq,njq]=size(Q);
P=X*(Q.*repmat((1./a)',niq,1));
if flip==1,X=X';
bidon=Q;Q=P;P=bidon;end;
% and that should be it !
function D=disteucl2(x,c)
% USAGE Y=disteucl2(X,Z)
% gives back 
% Y(I,K) matrix of the 
% squared euclidean distance
% between X(I,J) and Z(K,J)
% y(i,k)=(x[i]-z[k])'((x[i]-z[k])
% if Z is absent the distance is computed 
% between  the rows of X
%
if nargin==1;c=x;end;
[xni,xnj]=size(x);
% if xni==1;x=x';[xni,xnj]=size(x);end;
[cni,cnj]=size(c);
% if cni == 1;c=c';[cni,cnj]=size(c);end;
if cnj ~=xnj;
   error('c must have the same columns # as X ');
end
if xnj==1;
  D=(x.^2)*ones(1,cni) + ones(xni,1)*(c.^2)'-2*x*c';
else 
  x2=sum((x').^2)';c2=sum((c').^2);
  D=x2*ones(1,cni)+ones(xni,1)*c2-2*x*c';
end;

