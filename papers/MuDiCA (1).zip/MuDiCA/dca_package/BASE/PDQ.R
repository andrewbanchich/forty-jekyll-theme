###
# PDQ is going to be a version of paq, which is just an SVD call to help get rid of frighteningly low numbers.
###

PDQ <- function(datain,k=0){
	
	precisionLimit = 2*.Machine$double.eps
	svdOUT <- svd(datain)
	DELTAvec = as.vector(svdOUT$d)
	indToKeep = which(DELTAvec > precisionLimit)
	if((length(indToKeep) > k) && (k != 0)){
		indToKeep = indToKeep[1:k]
	}
	DELTAvec = DELTAvec[indToKeep]
	n_eigs = length(DELTAvec)
	DELTAdiag = diag(DELTAvec)
	P = svdOUT$u[,indToKeep]
	Q = svdOUT$v[,indToKeep]
	
	return(list(p=P,q=Q,Dv=DELTAvec,Dd=DELTAdiag,ng=n_eigs))
}