function [nfig]=PlotEllipses4DCA(fi,f_obs,f_obs_pred,FBoot,fj,lambda,Y,...
   nom_cat,ze_title,LesAxes,nfig,imp,gen_name,printype,printextension)
% USAGE [nfig]=PlotEllipses4DCA(fi,f_obs,f_obs_pred,FBoot,fj,...
%           lambda,Y,nom_cat,ze_title,LesAxes,...
%           nfig,imp,,gen_name,printype,printextension)    
%****************************************************************
% Plot Tolerance, Prediction and Confidence
%  Ellipses for a DICA type of analysis
%****************************************************************
% We have nI observations from nK groups, nJ variables and nL factors
% fi            : the nK*nL matrix of the group factor scores
% f_obs         : the nI*nL matrix of the observation factor scores
% f_obs_pred    : the nI*nL matrix of the 
%                 observation predicted factor scores
% FBoot         : the nI*nL*niter Bootstraped group factor scores 
% fj            : the nJ*nL matrix of the variable factor scores
% lambda        : the nL*1 vector of eigenvalue from DICA
% Y             : the nI*1 vector coding the group of the nI observations
% nom_cat       : the nK*1 cell array of the group names
% ze_title      : Generic title for the graph (default DICA)
% LesAxes       : 1*2 vector, gives the number of the axes to plot 
%                 (default: [1,2])
% nfig          : number of the first figure-1 (default = 0)
% imp           : 1 if we want to print the figures, 0 if not (default)
% gen_name      : generic name for graph file (default ("DICA_")
% printype      : type of graph (default "-depsc2")
% printextension: graph extension (default ".eps"
% ***************************************************************
% Output is nfig = number of the current figure
%
% ***************************************************************
% Current version February 16, 2010
% Herve Abdi. herve@utdallas.edu, www.utdallas.edu/~herve


NoVoc=1; % useless but kept for compatibility with previous versions

% printfigure=1 -> print the figure
% Need a file name
%

if exist('NoVoc')==0;NoVoc=1;end
% Check if nfig exist if not create it
if exist('nfig')==0;
 nfig=0;
end
if exist('LesAxes')==0;LesAxes=[1,2];end
% specify the axes of interest
%
ax1=LesAxes(1);
ax2=LesAxes(2);
if exist('imp')==0;imp=0;end
printfigure=imp;
if exist('gen_name')==0;gen_name='DICA_';end
if exist('ze_title')==0;ze_title='DICA ';end
if exist('printype')==0;printype='-depsc2';end
if exist('printextension')==0;printextension='.eps';end



% 1. plot the bootstrap here
%
% color for printing

 code_couleur=['r','m','y','b','g','c','k'];
 LesCouleurs=['b','g','c','r','m','y']';

%
% here  I convert the parameter of DCA
% to match the parameter of the ellipse program from DISTATIS
% PS -> Herve this is Beurk Programming
%
% nc is # of groups for the DCA
%
nc=size(fi,1);
nbeers=nc;
% F is the coordinates of the groups
F=fi;
%
for nn=1:nc;
 Nom_de_row{nn}=char(nom_cat{1,nn});
end
 

% Go for Confidence Ellipsoids on Bootstrap
%
% Confidence ellipsoid
% Plot  them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
%le_petit=min(squeeze(min(LeRF(:,:,:)))');
%le_grand=max(squeeze(max(LeRF(:,:,:)))');
le_petit=min(squeeze(min(FBoot(:,:,:)))');
le_grand=max(squeeze(max(FBoot(:,:,:)))');


p=[le_grand(1)-le_petit(1)]/10;
%le_petit=min([f_obs]);
%le_grand=max([f_obs]);
les_axesEl=[le_petit(ax1)-2*p,le_grand(ax1)+2*p,...
            le_petit(ax2)-2*p,le_grand(ax2)+2*p];
        All_F=[fi;fj;f_obs;f_obs_pred];
minc=min(All_F);
maxc=max(All_F);
percent_of_inertia=100*lambda./sum(lambda);
tc=round(percent_of_inertia);
p=[maxc(1)-minc(1)]/30;

les_axes=[minc(ax1)-p,maxc(ax1)+p,...
          minc(ax2)-p,maxc(ax2)+p]; 
les_axesEl=les_axes;    
% Bad fix here
% we force the value of les_axes to be equal
% to the value used by PlotDCAEllipses_ALW
% this makes both set of graphs plotted with the same
% scale. 
%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
%  ze_title='DCA ';
ze_tRC=[ze_title,' Confidence Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);

for k=1:ncp;
    %debut=(k-1)*npieces+1;
    %fin=debut+npieces-1;
    %partip_scores=f_obs(debut:fin,:);
    BootConf=squeeze(FBoot(k,:,:))';
    %truc=char(nom_cat{k});
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),BootConf(:,[ax1,ax2]),...
    code_couleur(k),truc(1))    
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='ConfElli';
    print(printype,[gen_name,nom_de_print,printextension])
end

% New version ChiChi
% Plot Pretty Ellipses
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% le_petit=min(squeeze(min(FBoot(:,:,:)))');
% le_grand=max(squeeze(max(FBoot(:,:,:)))');
% p=[le_grand(1)-le_petit(1)]/10;
% les_axesEl=[le_petit(ax1)-2*p,le_grand(ax1)+2*p,...
%             le_petit(ax2)-2*p,le_grand(ax2)+2*p];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Mean Confidence Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    BootConf=squeeze(FBoot(k,:,:))';
    truc=char(Nom_de_row(1,k)); % Use the one letter name
    PlotEllipse(F(k,[ax1,ax2]),BootConf(:,[ax1,ax2]),...
        code_couleur(k),truc(1))
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lambda(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lambda(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='ConfElli2';
    print(printype,[gen_name,nom_de_print,printextension])
end


%
% PLot the tolerance intervals here
% First the standard ones
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
% 
nfig=nfig+1;
figure(nfig);clf;
tolevel=.95; % tolerance interval level
ze_tRC=[ze_title,' Tolerance Interval (',int2str(tolevel*100),'%) '];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    %
    Fobs4plot=f_obs(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1,ax2]),...
    code_couleur(k),truc(1))    ;
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='TolElli';
    print(printype,[gen_name,nom_de_print,printextension])
end


% now the editable ones
% 
nfig=nfig+1;
figure(nfig);clf;

ze_tRC=[ze_title,' Tolerance Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    Fobs4plot=f_obs(Y==k,:);
    Fobs4plot=f_obs(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=char(Nom_de_row(1,k));
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1:ax2]),...
    code_couleur(k),truc(1)) ;
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lambda(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lambda(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='TolElli2';
    print(printype,[gen_name,nom_de_print,printextension])
end


% ******************************************************************
%
% PLot the prediction intervals here
% First the standard ones
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
% 
nfig=nfig+1;
figure(nfig);clf;
tolevel=.95; % tolerance interval level
ze_tRC=[ze_title,'Prediction Interval (',int2str(tolevel*100),'%) '];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];

% Plot empty names
ncp=nbeers;
 nom_vide=cellstr(char(ones(ncp,2)*32));
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(F,1,2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    %
    Fobs4plot=f_obs_pred(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=int2str(k);
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1,ax2]),...
    code_couleur(k),truc(1))    ;
     %   code_couleur(mod(k-1,7)+1),truc(1))
    
end

if printfigure==1;
    nom_de_print='PredElli';
    print(printype,[gen_name,nom_de_print,printextension])
end


% now the editable ones
% 
nfig=nfig+1;
figure(nfig);clf;

ze_tRC=[ze_title,' Prediction Interval (95%)'];
titre=[ze_tRC,' \tau_',int2str(ax1),'=',...
                   int2str(tc(ax1)),'%,', ...
                   ' \tau_',int2str(ax2),'=',...
                   int2str(tc(ax2)),'%'];
% Plot empty names
ncp=nbeers;
  % for nom_vide 32 is space
  %              42  is .
  %              46  is *
  LeSigne=32;
  LeSigne=46;
 nom_vide=cellstr(char(ones(ncp,2)*32));
 plotxyplain(F,1,2,nom_vide);hold('on')
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:ncp;
    Fobs4plot=f_obs_pred(Y==k,:);
    dev2center=Fobs4plot-repmat(F(k,:),size(Fobs4plot,1),1);
    d2=sum(dev2center.^2,2);
    [d2sort,index]=sort(d2);
    d2center=flipud(d2sort);
    F4plot=(Fobs4plot(index,:));
    n2keep=round(length(d2)*tolevel);
    %
    truc=char(Nom_de_row(1,k));
    PlotEllipse(F(k,[ax1,ax2]),F4plot(1:n2keep,[ax1:ax2]),...
    code_couleur(k),truc(1)) ;
    text(F(k,ax1), F(k,ax2),char(LeSigne),'FontSize',25,...
          'FontWeight','bold');
end
set(gca,'Visible','off')
lepas=les_axesEl(4)/12;
laVal=['\lambda_',int2str(ax1),'=.',int2str(round(lambda(ax1)*100))];
text(les_axesEl(1),lepas,laVal,'FontWeight','bold')
% Label for axis # 1
laVal=['\tau_',int2str(ax1),'=',int2str(tc(ax1)),'%'];
text(les_axesEl(1),-lepas,laVal,'FontWeight','bold')
text(les_axesEl(2)-lepas,lepas,int2str(ax1),...
         'FontSize',17,...
          'FontWeight','bold')
% Label for axis # 2
laVal=['\lambda_',int2str(ax2),'=.',int2str(round(lambda(ax2)*100))];
text(lepas,les_axesEl(3)+2*lepas,laVal,'FontWeight','bold')
laVal=['\tau_',int2str(ax2),'=',int2str(tc(ax2)),'%'];
text(lepas,les_axesEl(3)+.5*lepas,laVal,'FontWeight','bold')
text(lepas,les_axesEl(4)-lepas,int2str(ax2),...
         'FontSize',17,...
          'FontWeight','bold')
if printfigure==1;
    nom_de_print='PredElli2';
    print(printype,[gen_name,nom_de_print,printextension])
end

% *******************************************************************
% Sub-Functions
function PlotEllipse(fi,scores,code_couleur,nom)
%USAGE PlotEllipse(Fcenter,Felements,couleur,nom)
% Plot a category as color points
% Fcenter=coordinate of the center of the category
% Felements=coordinates of the points
% with the center of the category as a name: nom
% Plotted with one colour: couleur (can be a vector)
% along with the 95% confidence interval
% Experimental version. 
% Herve Abdi Ocotber 2006
% Uses draw_PCA_Ellipse from Joseph Dunlop

axe_horizontal=1;
axe_vertical=2;
[ns,nK]=size(scores);

text(fi(axe_horizontal),fi(axe_vertical),...
           nom,...
          'color',code_couleur,...
          'LineWidth',6,... 
          'FontSize',15,...
          'FontAngle','oblique',...
          'FontWeight','bold');
        
%     for j=1:ns;
%     % text(partip_scores(j,1),...
%     %      partip_scores(j,2),...
%     %      char(nc_jack(k)));
%      plot(scores(j,1),...
%           scores(j,2),...
%           'o',...
%           'color',code_couleur,...
%           'LineWidth',6,...
%           'MarkerSize',6);
%     end
    
  [coords,q,x_length,y_length,center_xy2]=...
      draw_PCA_ellipse(scores,code_couleur);

  
  
% %%%%% Functions Here:
%  draw_PCA_ellipse, paq, disteucl2  
function [coords,q,x_length,y_length,center_xy2] =...
                        draw_PCA_ellipse(X,colour,width_ell)
% [coords,q,x_length,y_length,center_xy] =
% draw_PCA_ellipse_extra(X,colour,width_ell)
% draw_PCA_ellipse creates a containing ellipse for a set of points (X)
% the function centers and performs a pca on points (to get rotation)
% takes the outermost points of absolute value (convex hull)
% and generates an ellipse that just contains these points
% the ellipse is generated by determining the ratio of major/minor axes,
% the ellipse is scaled by the point most distant from the centroid
% according to this proportion
% once the major/minor axes sizes are determined, a set of poins to be
% graphed defining the ellipse is generated, rotated, recentered and
% returned
% overloaded options colour (color) and width define the color and
% pixel-width
% parameters for the ellipse, default is blue and 3 pixels
% returned parameters: 
% coords - coordinates of the polygon approximating the ellipse
% q - rotation matrix
% x-length, y-length - length major and minor axes respectively
% center_xy2 - barycenter of the 95% cloud of points
% note, this function depends on:
% disteucl2, paq 
% check # of args
%  Joseph Dunlop. October 19. 2006

if nargin == 1; colour = '-b'; width_ell = 3; end
if nargin == 2; width_ell = 3; end
% first we need to reduce the set of points to the 95% closest to the
% barycenter
[r,c] = size(X);
center_xy = sum(X,1)/r; % find the center
% determine the 95% closest points and remove the rest
dist_X = [disteucl2(X, center_xy) X];
C = sortrows(dist_X,1);
C((ceil(.95*r)+1):r,:) = []; % trim 95%
C(:,1)=[]; % trim the distances
% now we'll center the ellipse, then perform a pca, remaining work will
% be done from rotated coords
[r2,c2] = size(C);
center_xy2 = sum(C,1)/r2; 
% find the center
[p,a,q] = paq(C - ones(r2,1)*center_xy2);
% pca on the centered set of points
F = p*diag(a); 
% find the projections onto the new axes
% reduce to convex hull of the abs values of the points by adding
% max_x,max_y and origin points
F_temp = abs(F); % collapse to quadrant 2
F_temp = [F_temp; 0 0; max(F_temp(:,1)) 0; 0 max(F_temp(:,2))]; 
% 'complete' the rectangle
k = convhull(F_temp(:,1), F_temp(:,2)); 
% find the hull composed of the these points
junk = find(k >length(F));
k(find(k > length(F))) = [];
F_hull = abs(F(k,:));
% we'll use the proportion of interia along each axis (contained in 'a') as
% our proportion in determing the major/minor axis of the ellipse
c_1 = a(1)/a(2);
y_length = max(sqrt((F_hull(:,1).^2)./(c_1^2) + (F_hull(:,2).^2)));
x_length = y_length*c_1;
% we'll use these lengths to draw the ellipse
j = pi/64:pi/64:2*pi;
coords = [cos(j')*x_length sin(j')*y_length];
coords = coords*q' + ones(length(j),1)*center_xy2;
% rotate by cosines (q') and recenter to center of points (center_xy)
% plot the coords as an ellipse
plot([coords(:,1);coords(1,1)],...
    [coords(:,2);coords(1,2)],...
    colour, 'LineWidth',width_ell);

function [P,a,Q]=paq(X,k);
%USAGE [P,a,Q]=paq(X,k);
% k-Singular value decomposition of the I by J matrix X
%if k is not present then k=min{I,J}
%if k is larger larger than min{I,J} then k= min
%if k is larger than K=the actual number 
%        of singular values, then k=K
% the singular vectors and values are ordered
% in decreasing order
% P are the eigenvectors of X'X
% Q are the eigenvector of XX'
% a is the vector of the SINGULAR values
% NOTE that a = sqrt(lambda)
% where lambda are the eigenvalues of both X'X and XX'
%% Herve Abdi. October 2004 (revised version)
% 
   epsilon=2*eps;
%  tolerance to be considered 0 for an eigenvalue
[I,J]=size(X);
m=min(I,J); 
if nargin==1, k=m;
        else if k > m, k=m;end;
     end;
flip=0; 
if I < J, X=X';flip=1;end;
% Incorporate eigen routine here %%%%%
  [Q,l]=eig(X'*X);
  l=diag(l);
  [l,k2]=sort(l);
  n=length(k2);
  l=l((n+1)-(1:n));
  Q=Q(:,k2((n+1)-(1:n)));
% keep the non-zero eigen value only (tolerance=epsilon)
  pos=find(any([l';l'] > epsilon ));
  l=l(pos);
  Q=Q(1:n,pos);
 %%%%%% End of Eigen %%%%%%%%%%%%%%%%%
ll= max(size(l)); if k > ll, k=length(l);end;
Q=Q(:,1:k);
l=l(1:k);
a=sqrt(l);
[niq,njq]=size(Q);
P=X*(Q.*repmat((1./a)',niq,1));
if flip==1,X=X';
bidon=Q;Q=P;P=bidon;end;
% and that should be it !
function D=disteucl2(x,c)
% USAGE Y=disteucl2(X,Z)
% gives back 
% Y(I,K) matrix of the 
% squared euclidean distance
% between X(I,J) and Z(K,J)
% y(i,k)=(x[i]-z[k])'((x[i]-z[k])
% if Z is absent the distance is computed 
% between  the rows of X
%
if nargin==1;c=x;end;
[xni,xnj]=size(x);
% if xni==1;x=x';[xni,xnj]=size(x);end;
[cni,cnj]=size(c);
% if cni == 1;c=c';[cni,cnj]=size(c);end;
if cnj ~=xnj;
   error('c must have the same columns # as X ');
end
if xnj==1;
  D=(x.^2)*ones(1,cni) + ones(xni,1)*(c.^2)'-2*x*c';
else 
  x2=sum((x').^2)';c2=sum((c').^2);
  D=x2*ones(1,cni)+ones(xni,1)*c2-2*x*c';
end;

