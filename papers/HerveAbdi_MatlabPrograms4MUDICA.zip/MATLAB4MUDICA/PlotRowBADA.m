function [nfig]=plotRowBADA(...
lambda,fi,Y,f_obs,fi_sup_jackrec,nom_cat,nom_r,...
ze_title,graph_gen,...
nfig,imp,LesAxes,printype,extprint)
%USAGE: [nfig]=plotRowBADA(lambda,fi,Y,f_obs,f_obs_pred,...
%           nom_cat,nom_r,ze_title,gen_name,...
%           nfig,imp,LesAxes,printype,printextension]
% Plot the rows of DICA type of analysis. With some ellipsoids.
% INPUT:
% [We have nI observations from nK groups, nJ variables and nL factors]
% lambda        : the nL*1 vector of eigenvalue from DICA
% fi            : the nK*nL matrix of the group factor scores
% Y             : the nI*1 vector coding the group of the nI observations
% f_obs_pred    : the nI*nL matrix of the 
%                observation predicted factor scores
% nom_cat       : the nK*1 cell array of the group names
% nom_r         : the nI*1 cell array of the group names
% ze_title      : Generic title for the graph (default DICA)
% gen_name      : generic name for graph file (default ("DICA_")
% nfig          : number of the first figure-1 (default = 0)
% imp           : 1 if we want to print the figures, 0 if not (default)
% LesAxes       : 1*2 vector, gives the number of the axes to plot 
%                 (default: [1,2])
% printype      : type of graph (default "-depsc2")
% printextension: graph extension (default ".eps"
% ***************************************************************
% Current version February 18, 2010.
% Herve Abdi. herve@utdallas.edu
% www.utdallas.edu
%

if exist('LesAxes')~=1;LesAxes=[1,2]';end
ax1=LesAxes(1);ax2=LesAxes(2);
if exist('extprint')~=1;
    extprint='.eps';
end
if exist('printype')~=1;
    printype='-depsc';
end
if exist('f_isup')~=1;
    f_isup=[];nom_rs=[];
end
% % 
if exist('nI')~=1;
    nI=size(f_obs,1);
end
% %  The axes to keep for the plots
% default 1 and 2
if exist('axe_horizontal')~=1;
  axe_horizontal=ax1;
end
if exist('axe_vertical')~=1;
   axe_vertical=ax2;
end   
if size(Y,2)==1;  % If Y give the cat number
    Y=dummy_of(Y);% transform it into a 0/1 group matrix
end
[nc]=size(fi,1);
%
% Make sure that we have the same 
% coordinates system for the rows and the columns
% 
All_F=[fi;f_obs];
minc=min(All_F);
maxc=max(All_F);
percent_of_inertia=100*lambda./sum(lambda);
p=[maxc(1)-minc(1)]/30;
les_axes=[minc(axe_horizontal)-p,maxc(axe_horizontal)+p,...
          minc(axe_vertical)-p,maxc(axe_vertical)+p];  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% Plot here 
if exist('nfig')~=1;nfig=0;end

nfig=nfig+1;figure(nfig);clf
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %  Now plot the Groups
% %  on the Factors
ze_tRC=[ze_title,' Groups.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
plotxyha(fi,ax1,ax2,titre,nom_cat');
axis(les_axes);axis('equal')
if imp==1;
    nom_de_g=[graph_gen,'Centers',extprint];
    print(printype,nom_de_g);
end
% %
% %  Now plot the projections of the "observations"
% %  and Groups
% %  on the Factors
%%%%
nfig=nfig+1;figure(nfig);clf
ze_tR=[ze_title,' Groups & Observations.'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
plotxyha([f_obs;f_isup;fi],ax1,ax2,titre,[nom_r';nom_rs';nom_cat']);
axis(les_axes);axis('equal')
if imp==1;
    nom_de_g=[graph_gen,'Rows',extprint];
    print(printype,nom_de_g);
end
% 
% % %%% Make the graph with the centers %%%%%%%%%%%%%%%%%
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for k=1:nc;
%     truc=char(nom_cat{k});
%     nc_jack(k)={truc(1)};
% end
% nfig=nfig+1;figure(nfig);clf;clf
% ze_tRC=[ze_title,' Groups jackknife.'];
% titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
%                    int2str(percent_of_inertia(axe_horizontal)),'%,', ...
%                    ' \tau_',int2str(axe_vertical),'=',...
%                    int2str(percent_of_inertia(axe_vertical)),'%'];
% plotxyha(fi,1,2,titre,nom_cat');
% axis(les_axes);axis('equal')
% hold on
% for i=1:nI;
%     for k=1:nc
%      text(fi_jack(k,1,i),fi_jack(k,2,i),char(nc_jack(k)))
%     end
% end
% 
% 
% if imp==1;
%     nom_de_g=[graph_gen,'CentersJack',extprint]
%     print(printype,nom_de_g)
% end
% % %

%%%% Make the Convex Hull here
%  Make the convex hulls for the groups 
%  for Dimensions 1 and 2
nfig=nfig+1;
figure(nfig);clf;
%
npgroup=sum(Y);
nc=length(npgroup);
max_group=max(npgroup);
%
axis_obs=zeros(nc,max_group,2); 
for i=1:nc; 
       les_indices=find(Y(:,i)==1);
       axis_obs(i,1:npgroup(i),:)=f_obs(les_indices,[ax1,ax2]);
end
plotxyrange(fi,ax1,ax2,...
   'Classes & Convex Hulls',nom_cat',...
   [minc(ax1),maxc(ax1),minc(ax2),maxc(ax2)])
code_couleur=['r','g','b','y','m','c','k']; 
mark=code_couleur';
for i=1:nc
  coul=mark(mod(i-1,7)+1,:); 
  x=axis_obs(i,1:npgroup(i),1);
  y=axis_obs(i,1:npgroup(i),2);
  KK=convhull(x,y);
  plot(x(KK),y(KK),[coul,'-'],x,y,[coul,'+'],'LineWidth',2);
  lenom=char(nom_cat{i});
  text(fi(i,ax1),fi(i,ax2),lenom,'Color',coul)
  K2=length(KK);
  for k2=1:K2;
       plot([x(KK(k2)),fi(i,ax1)],[y(KK(k2)),fi(i,ax2)],...
         [coul,':'],'LineWidth',1.5);
  end
end
if imp==1;
    nom_de_g=[graph_gen,'ConvHull',extprint];
    print(printype,nom_de_g);
end
%%%% End of Convex Hull


% Tolerance ellipsoid
% Plot  them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
le_petit=min([f_obs;fi_sup_jackrec]);
le_grand=max([f_obs;fi_sup_jackrec]);
%
les_axesEl=[le_petit(axe_horizontal)-5*p,le_grand(axe_horizontal)+5*p,...
            le_petit(axe_vertical)-5*p,le_grand(axe_vertical)+5*p];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Tolerance 95% ellipsoids'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
 
% Plot empty names             
 nom_vide=cellstr(char(ones(nc,2)*32));           
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(fi,ax1,ax2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:nc;
    les_indices=find(Y(:,k)==1);
    %debut=(k-1)*npieces+1;
    %fin=debut+npieces-1;
    partip_scores=f_obs(les_indices,[ax1,ax2]);
    truc=char(nom_cat{k});
    PlotClassEllipse(fi(k,[ax1,ax2]),partip_scores,code_couleur(k),truc(1))
end
if imp==1;
    nom_de_g=[graph_gen,'ToleranceElli',extprint];
    print(printype,nom_de_g);
end

% Prediction ellipsoid
% Plot  them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
le_petit=min([f_obs;fi_sup_jackrec]);
le_grand=max([f_obs;fi_sup_jackrec]);
les_axesEl=[le_petit(axe_horizontal)-5*p,le_grand(axe_horizontal)+5*p,...
            le_petit(axe_vertical)-5*p,le_grand(axe_vertical)+5*p];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Prediction 95% ellipsoids'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
 
% Plot empty names             
 nom_vide=cellstr(char(ones(nc,2)*32));           
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(fi,ax1,ax2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',2);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',2);
for k=1:nc;
    les_indices=find(Y(:,k)==1);
    %debut=(k-1)*npieces+1;
    %fin=debut+npieces-1;
    partip_scores=fi_sup_jackrec(les_indices,[ax1,ax2]);
    truc=char(nom_cat{k});
    PlotClassEllipse(fi(k,[ax1,ax2]),partip_scores,code_couleur(k),truc(1))
end
if imp==1;
    nom_de_g=[graph_gen,'PredictionElli',extprint];
    print(printype,nom_de_g);
end

 

% Pretty Graph For the center
%
% Plot  them
nfig=nfig+1;
figure(nfig);clf;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get the axes right
le_petit=min([f_obs]);
le_grand=max([f_obs]);
les_axesEl=[le_petit(axe_horizontal)-5*p,le_grand(axe_horizontal)+5*p,...
            le_petit(axe_vertical)-5*p,le_grand(axe_vertical)+5*p];

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Now plot the Groups
%  on the Factors
ze_tRC=[ze_title,' Class Centers'];
titre=[ze_tRC,' \tau_',int2str(axe_horizontal),'=',...
                   int2str(percent_of_inertia(axe_horizontal)),'%,', ...
                   ' \tau_',int2str(axe_vertical),'=',...
                   int2str(percent_of_inertia(axe_vertical)),'%'];
 
% Plot empty names             
 nom_vide=cellstr(char(ones(nc,2)*32));           
% plotxyha(fi,1,2,titre,nom_cat');
 plotxyha(fi,ax1,ax2,titre,nom_vide);
axis(les_axesEl);axis('equal')
couleur_axes='k';
plot([les_axesEl(1);les_axesEl(2)],[0 0],...
    couleur_axes, 'LineWidth',3);
plot([0 0],[les_axesEl(3);les_axesEl(4)],...
    couleur_axes, 'LineWidth',3);
for k=1:nc;
    text(fi(k,ax1),fi(k,ax2),char(nom_cat{k}),...
        'FontWeight','bold',...
        'FontSize',18,...
        'Color',code_couleur(k)),
end
if imp==1;
    nom_de_g=[graph_gen,'ColorCenters',extprint];
    print(printype,nom_de_g);
end
 


function plotxyrange(F,axe1,axe2,titre,noms,range);
% % ***** This is a Test  Version *******
% January  1999 Herve Abdi
% Usage plotxyabs(F,axe1,axe2,title,names,range);
% plotxy plots a MDS or PCA or CA graph of component #'Axe1' vs #'Axe2'
% F is a matrix of coordinates
% axe1 is the Horizontal Axis
% axe2 is the Vertical Axis
% title will be the title of the graph
% range is a 1*4 vector giving
% the [minx,maxx,miny,maxy] values (def as plotxyha)
% Axes are labelled 'Principal Component number'
% names give the names of the points to plot (def=numbers)
% see also plotxyha , plotxyha2, plotxyabs
% difference in dealing with the names and the first axis
% plotxyabs plot the First axis as starting at 0.


[nrow,ncol]=size(F);
if exist('noms')==0;
   noms{nrow,1}=[];
   for k=1:nrow;noms{k,1}=int2str(k);end
end
if isa(noms,'char')==1;
   nomdenom=noms;clear noms;
   noms{nrow,1}=[];
   for k=1:nrow;noms{k,1}=nomdenom(k,:);end
end

if exist('range')==0;
 minx=min(F(:,axe1));
 maxx=max(F(:,axe1));
 miny=min(F(:,axe2));
 maxy=max(F(:,axe2));
range=[minx,maxx,miny,maxy]; 
%[minx,maxx,miny,maxy]=range(:);
else
minx=range(1);maxx=range(2);
miny=range(3);maxy=range(4);
end
hold off; clf;hold on;
 rangex=maxx-minx;epx=rangex/10;
 rangey=maxy-miny;epy=rangey/10; axis('equal');
 axis([minx-epx,maxx+epx,miny-epy,maxy+epy]) ;
 %axis('equal');
%axis;
plot ( F(:,axe1),F(:,axe2 ),'.');
label=' Principal Component Number ';
labelx=[label, num2str(axe1) ];
labely=[label, num2str(axe2) ];
xlabel (labelx);
ylabel (labely );
plot([minx-epx,maxx+epx],[0,0] ,'b');
% hold
plot ([0,0],[miny-epy,maxy+epy],'b');
for i=1:nrow,
  text(F(i,axe1),F(i,axe2),noms{i,1});
end;
title(titre);

function PlotClassEllipse(fi,scores,code_couleur,nom)
%USAGE PlotClassEllipse(Fcenter,couleur,nom)
% Plot a category as color points
% Fcenter=coordinate of the center of the category
% Felement=coordinates of the points
% with the center of the category as a name: nom
% Plotted with one colour: couleur (can be a vector)
% along with the 95% confidence interval
% Experimental version. 
% Herve Abdi Ocotber 2006
% Uses draw_PCA_Ellipse from Joseph Dunlop

axe_horizontal=1;
axe_vertical=2;
[ns,nK]=size(scores);

text(fi(axe_horizontal),fi(axe_vertical),...
           nom,...
          'color',code_couleur,...
          'LineWidth',6,... 
          'FontSize',15,...
          'FontAngle','oblique',...
          'FontWeight','bold');
        
    for j=1:ns;
    % text(partip_scores(j,1),...
    %      partip_scores(j,2),...
    %      char(nc_jack(k)));
     plot(scores(j,1),...
          scores(j,2),...
          'o',...
          'color',code_couleur,...
          'LineWidth',6,...
          'MarkerSize',6);
    end
    
  [coords,q,x_length,y_length,center_xy2]=...
      draw_PCA_ellipse(scores,code_couleur);

  
  
% %%%%% Functions Here:
%  draw_PCA_ellipse, paq, disteucl2  
function [coords,q,x_length,y_length,center_xy2] = draw_PCA_ellipse(X,colour,width_ell)
% [coords,q,x_length,y_length,center_xy] =
% draw_PCA_ellipse_extra(X,colour,width_ell)
% draw_PCA_ellipse creates a containing ellipse for a set of points (X)
% the function centers and performs a pca on points (to get rotation)
% takes the outermost points of absolute value (convex hull)
% and generates an ellipse that just contains these points
% the ellipse is generated by determining the ratio of major/minor axes,
% the ellipse is scaled by the point most distant from the centroid
% according to this proportion
% once the major/minor axes sizes are determined, a set of poins to be
% graphed defining the ellipse is generated, rotated, recentered and
% returned
% overloaded options colour (color) and width define the color and
% pixel-width
% parameters for the ellipse, default is blue and 3 pixels
% returned parameters: 
% coords - coordinates of the polygon approximating the ellipse
% q - rotation matrix
% x-length, y-length - length major and minor axes respectively
% center_xy2 - barycenter of the 95% cloud of points
% note, this function depends on:
% disteucl2, paq 
% check # of args
%  Joseph Dunlop. October 19. 2006

if nargin == 1; colour = '-b'; width_ell = 3; end
if nargin == 2; width_ell = 3; end
% first we need to reduce the set of points to the 95% closest to the
% barycenter
[r,c] = size(X);
center_xy = sum(X,1)/r; % find the center
% determine the 95% closest points and remove the rest
dist_X = [disteucl2(X, center_xy) X];
C = sortrows(dist_X,1);
%C((ceil(.95*r)+1):r,:) = []; % trim 95%
C((round(.95*r)+1):r,:) = []; % trim 95%
C(:,1)=[]; % trim the distances
% now we'll center the ellipse, then perform a pca, remaining work will
% be done from rotated coords
[r2,c2] = size(C);
center_xy2 = sum(C,1)/r2; 
% find the center
[p,a,q] = paq(C - ones(r2,1)*center_xy2);
% pca on the centered set of points
F = p*diag(a); 
% find the projections onto the new axes
% reduce to convex hull of the abs values of the points by adding
% max_x,max_y and origin points
F_temp = abs(F); % collapse to quadrant 2
F_temp = [F_temp; 0 0; max(F_temp(:,1)) 0; 0 max(F_temp(:,2))]; 
% 'complete' the rectangle
k = convhull(F_temp(:,1), F_temp(:,2)); 
% find the hull composed of the these points
junk = find(k >length(F));
k(find(k > length(F))) = [];
F_hull = abs(F(k,:));
% we'll use the proportion of interia along each axis (contained in 'a') as
% our proportion in determing the major/minor axis of the ellipse
c_1 = a(1)/a(2);
y_length = max(sqrt((F_hull(:,1).^2)./(c_1^2) + (F_hull(:,2).^2)));
x_length = y_length*c_1;
% we'll use these lengths to draw the ellipse
j = pi/64:pi/64:2*pi;
coords = [cos(j')*x_length sin(j')*y_length];
coords = coords*q' + ones(length(j),1)*center_xy2;
% rotate by cosines (q') and recenter to center of points (center_xy)
% plot the coords as an ellipse
plot([coords(:,1);coords(1,1)],...
    [coords(:,2);coords(1,2)],...
    colour, 'LineWidth',width_ell);

function [P,a,Q]=paq(X,k);
%USAGE [P,a,Q]=paq(X,k);
% k-Singular value decomposition of the I by J matrix X
%if k is not present then k=min{I,J}
%if k is larger larger than min{I,J} then k= min
%if k is larger than K=the actual number 
%        of singular values, then k=K
% the singular vectors and values are ordered
% in decreasing order
% P are the eigenvectors of X'X
% Q are the eigenvector of XX'
% a is the vector of the SINGULAR values
% NOTE that a = sqrt(lambda)
% where lambda are the eigenvalues of both X'X and XX'
%% Herve Abdi. October 2004 (revised version)
% 
   epsilon=2*eps;
%  tolerance to be considered 0 for an eigenvalue
[I,J]=size(X);
m=min(I,J); 
if nargin==1, k=m;
        else if k > m, k=m;end;
     end;
flip=0; 
if I < J, X=X';flip=1;end;
% Incorporate eigen routine here %%%%%
  [Q,l]=eig(X'*X);
  l=diag(l);
  [l,k2]=sort(l);
  n=length(k2);
  l=l((n+1)-(1:n));
  Q=Q(:,k2((n+1)-(1:n)));
% keep the non-zero eigen value only (tolerance=epsilon)
  pos=find(any([l';l'] > epsilon ));
  l=l(pos);
  Q=Q(1:n,pos);
 %%%%%% End of Eigen %%%%%%%%%%%%%%%%%
ll= max(size(l)); if k > ll, k=length(l);end;
Q=Q(:,1:k);
l=l(1:k);
a=sqrt(l);
[niq,njq]=size(Q);
P=X*(Q.*repmat((1./a)',niq,1));
if flip==1,X=X';
bidon=Q;Q=P;P=bidon;end;
% and that should be it !
function D=disteucl2(x,c)
% USAGE Y=disteucl2(X,Z)
% gives back 
% Y(I,K) matrix of the 
% squared euclidean distance
% between X(I,J) and Z(K,J)
% y(i,k)=(x[i]-z[k])'((x[i]-z[k])
% if Z is absent the distance is computed 
% between  the rows of X
%
if nargin==1;c=x;end;
[xni,xnj]=size(x);
% if xni==1;x=x';[xni,xnj]=size(x);end;
[cni,cnj]=size(c);
% if cni == 1;c=c';[cni,cnj]=size(c);end;
if cnj ~=xnj;
   error('c must have the same columns # as X ');
end
if xnj==1;
  D=(x.^2)*ones(1,cni) + ones(xni,1)*(c.^2)'-2*x*c';
else 
  x2=sum((x').^2)';c2=sum((c').^2);
  D=x2*ones(1,cni)+ones(xni,1)*c2-2*x*c';
end;
function  [Xrec,nom_c]=dummy_of(x)
% USAGE [Xrecnval]=dummy_of(x)
% transform a vector x into a dummy matrix X
% x is a vector with different values
% (not ordered and with possible gaps
% Xrec is dummy coding matrix
% after the values of x have been 
%   replaced by unique ordered values
% nval i a string array 
%   it gives the recoding values for x
%   (i.e. the columns of Xrec)
% Herve Abdi January 2006
[U_S,m,recS]=unique(x);
% U_S containts the "unique values of S
% recS containts the renumbered values
n_S=length(m);
% # of different values of S
ni=length(x) ;
Xrec=zeros(ni,n_S);
les_uns=sub2ind(size(Xrec),  [1:ni]',recS);
%dummy_S([ [1:ni]',recS])=ones(ni,1)
Xrec(les_uns)=1;
nval_n=x(m);
n=0;
for k=1:length(nval_n);
nom_c(k)={[num2str(nval_n(k))]}; 
end
