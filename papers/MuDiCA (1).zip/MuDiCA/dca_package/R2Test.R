####
# A function for calculating Fisher ratio and p-values...
# fobs is calculated observations
# classes = Y 
# massobs is the mass for the observations
####

R2Test <- function(fobs,classes,massobs,permutations=1000){
	dim_fobs = dim(fobs)
	dim_classes = dim(classes)
	
	
	R2_ret <- R2routine(fobs,classes,dim_classes[2],dim_fobs[1],massobs)
	R2 = R2_ret$r2
	fish = (R2/(1-R2)) * ((dim_fobs[1]-dim_classes[2])/(dim_classes[2]-1))
	p_pdf = df(fish,dim_classes[2]-1,dim_fobs[1]-dim_classes[2])
	p_cdf = 1-pf(fish,dim_classes[2]-1,dim_fobs[1]-dim_classes[2])
	
	#Dr Abdi is calculating & returning fpdf, which would be p_pdf here.
	
	print('Beginning Permutation Calculation')
	pb <- txtProgressBar(1,permutations,1,style=1)
	R2_for_perms = array(0,permutations)
	#just an initialization
	F_for_perms = R2_for_perms
	p_track = 0
	#R is not as graceful with vector or matrix calculations, as MatLab
	#Since I have to use a loop anyways - just use it to do all the vector based calculations here.
	
	for(i in 1:permutations){
		classes_for_perms = classes[randperm(dim_fobs[1]),]
		R2_for_perms[i] = R2routine(fobs,classes_for_perms,dim_classes[2],dim_fobs[1])$r2
		F_for_perms[i] = ((R2_for_perms[i]/(1-R2_for_perms[i])) * ((dim_fobs[1]-dim_classes[2])/(dim_classes[1]-1)))
		if(R2_for_perms[i] > R2){
			p_track = p_track + 1
		}
		setTxtProgressBar(pb,i)
	}
	p_track = p_track / permutations
	print('Permutation Calculation Complete')
	#return(list(r2=R2,f=fish,pcdf=p_cdf,ppdf=p_pdf,r2perm=R2_for_perms,fperm=F_for_perms,pperm=p_track))
	return(list(r2=R2,f=fish,pcdf=p_cdf,ppdf=p_pdf,pperm=p_track,r2sim=R2_for_perms,fsim=F_for_perms))
}

R2routine <- function(fobs,classes,classcol,fobsrow,massobs=0){
	if(massobs == 0){
		massobs = matrix(1,fobsrow,1)%*%(1/fobsrow)
	}
	M = classes * repmat(massobs,1,classcol)
	mSums = colSums(M)
	barycenter = diag((1/mSums)) %*% (t(M) %*% fobs)
	tM = t(mSums)
	center = tM %*% barycenter
	centerRep = repmat(center,fobsrow,1)
	#I can call for an F test here, instead?
	SStot = sum(massobs * (rowSums(((fobs - centerRep)^2))))
	SSbary = sum(massobs * (rowSums((((classes %*% barycenter) - centerRep)^2))))
	#F ratio
	R2 = SSbary/SStot
	return(list(st=SStot,sb=SSbary,r2=R2))
}