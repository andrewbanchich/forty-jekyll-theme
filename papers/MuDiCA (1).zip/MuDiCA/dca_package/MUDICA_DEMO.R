#########################################################################################
# This function is the over all controlling function. It is by no means user friendly.
# It adheres partially to modularity, while partially adhere to hackery to get stuff done.
#
# This function serves as a guide on how to approach a more user friendly DCA, by presenting
# the order of functions, their parameters, and their results (returns).
#
#########################################################################################
MUDICA_DEMO <- function(data_mat,group_mat=0,block_mat=0,sup_mat=0,interval=0.95,plot_block_data=0,vars=FALSE,file_mat_flag=1,jackknife=1,boot_sample=100,variable_plots=0,num_comparisons=0,plot_text="My Plot")
{

	###init return values
	#####################
	ret_DCA=NULL
	ret_Sup=NULL
	assignments=NULL
	minMaxList=NULL
	jkDCA=NULL
	tableData=NULL
	bootstrap_back=NULL
	ret_R2=NULL
	#####################
	
	#Send axes in... how to select or check for them?
	#If the user provides any wrong axis, just default to 1,2
	##TODO: Allow user inputted axes.
	axis1 = 1
	axis2 = 2
	pc = "Principal Component: "
	intervalPercentage = paste(100*interval," %")
	
	#The core data. Loaded no matter what.
	ret_data <- dcaDataLoader(data_mat,group_mat,block_mat,sup_mat,vars,file_mat_flag)
	X = ret_data$x
	Y = ret_data$y
	#Z is being angry and returning an extra line at the end?
	Z = ret_data$z
	
	#Get color and point styles for the classes.
	cpsu <- colorPoints(Y)
	
	#And we are off!
	print('Begin MuDiCA Fixed Effect')
	ret_DCA <- dca(X,Y,Z)
	print('DiCA Complete')
	
	F = ret_DCA$f
	G = ret_DCA$g
	l = ret_DCA$l
	S = ret_DCA$S
	spp = ret_DCA$spp
	c = ret_DCA$c
	tau = ret_DCA$tau
	
	ret_Sup <- supplementaryObservationPoints(l,X,F)
	fobs = ret_Sup$sup
	profile = ret_Sup$profile
	deltainv = ret_Sup$i
			
	ret_SCos <- squaredCosines(l,fobs)
	fo2 <- ret_SCos$fo2
	d_obs <- ret_SCos$d_obs
	c_obs <- ret_SCos$c_obs
		
	assignments <- obsToCenter(Y,fobs,G)
	Dsup <- assignments$sup
	assigned <- assignments$assigned
	confusion  <- assignments$confusion
	
	######################### Proper Axis Labeling #####################
	pc_text1 = paste(pc,axis1)
	pc_text1 = paste(pc_text1, " tau: %")
	pc_text1 = paste(pc_text1, round(tau[1],2))
	pc_text2 = paste(pc,axis2)
	pc_text2 = paste(pc_text2, " tau: %")
	pc_text2 = paste(pc_text2, round(tau[2],2))
	######################### Proper Axis Labeling #####################
		
	####################################################################
	#Permutation Test Calculations
	print('Permutation Test Calls on Fixed Effect')
	massobs = rowSums(X)/spp
	ret_R2 <- R2Test(fobs,Y,massobs)
	####################################################################

	if(jackknife){
		print('Begin MuDiCA Jackknife Calculations')
		jkDCA <- jkDCA(X,Y,Z,ret_DCA)
		fobs_predicted = jkDCA$fobspred
		print('End MuDiCA Jackknife Calculations')		
	}
	if(boot_sample > 99){
		print('Begin MuDiCA Bootstrap Calculations')
		bootstrap_back <- bootstrap(X,Y,F,l,boot_sample)
		fboots = bootstrap_back$fboot
		print('End MuDiCA Bootstrap Calculations')
	}
	
			
	###############CALCULATE MIN AND MAX FOR PLOTS######################
	mmHelp <- minmaxHelper(G,fobs)
	minMaxMatrix <- mmHelp$tmm
	mmHelp <- minmaxHelper(minMaxMatrix,F)
	minMaxMatrix <- mmHelp$tmm
	if(jackknife){	
		mmHelp <- minmaxHelper(minMaxMatrix,fobs_predicted)
		minMaxMatrix <- mmHelp$tmm		
	}
	if(boot_sample > 99){
		mmHelp <- minmaxHelper(minMaxMatrix,fboots)
		minMaxMatrix <- mmHelp$tmm
	}
	
	minMaxList <- mmHelp$mml
	### A BUFFER ZONE ###
	minMaxList$minx = minMaxList$minx * 1.1
	minMaxList$maxx = minMaxList$maxx * 1.1
	minMaxList$miny = minMaxList$miny * 1.1
	minMaxList$maxy = minMaxList$maxy * 1.1				
	####################################################################

	
	#The Mu part of MuDICA!!
	########################BLOCK SPECIFIC##############################
	####################################################################
	if(plot_block_data){
		#Block Projection Calculations
		print('Block Projection Calculations')
		block_dims = dim(Z)
		rowMass = colSums(S)/spp
		colWeight = rowSums(S)/spp
		colPoints = t(c)
		tablePoints = Z %*% colPoints
		blockPoints = 1/tablePoints
		tableWeights = Z * repmat(c,block_dims[1],1)
		tableBarys = repmat(blockPoints,1,length(l)) * (tableWeights %*% F)
		tableInertias = (tableWeights %*% (F^2))
		tableContributions = tableInertias/repmat(t(l),block_dims[1],1)		
		####################################################################
		tableData <- list(tc=tableContributions,ti=tableInertias,tb=tableBarys)
	}
	########################BLOCK SPECIFIC##############################


	####A NOTE TO USERS: You will want to change the text for main= for all graphs.####
	#PLOTTING STUFF
	print('Begin MuDiCA Fixed Effect Plots')
	dcaPlotText = paste(plot_text, " Tolerance ")
	dcaPlotText = paste(dcaPlotText, intervalPercentage)
	dcaPlot(cpsu,axis1,axis2,Y,G,fobs,l,minMaxList,plot_ellipses=interval,main=dcaPlotText,sub="Fixed Effect",xlab=pc_text1,ylab=pc_text2)
	if(variable_plots){
		varPlotText = paste(plot_text, " Original Group Centers and All Variables")
		varPlotter(cpsu,axis1,axis2,F,Y,G,fobs,lambda,minMaxList,1,0,vars_available=vars,datain=X,main=varPlotText,sub="Variables Plot",xl=pc_text1,yl=pc_text2)
	}
	print('End MuDiCA Fixed Effect Plots')
	
	if(jackknife){
		jkPlotText = paste(plot_text, " Prediction ")
		jkPlotText = paste(jkPlotText, intervalPercentage)
		jkPlotTextO = paste(jkPlotText, " - Original Group Centers")
		jkPlotTextP = paste(jkPlotText, " - Predicted Group Centers")		
		print('Begin MuDiCA Jackknife Plots')
		jkPlot(fobs_predicted,cpsu,G,Y,axis1,axis2,l,minMaxList,plot_ells=interval,main=jkPlotTextO,sub="Random Effects - Original Centers",xlab=pc_text1,ylab=pc_text2)
		jkPlot(fobs_predicted,cpsu,G,Y,axis1,axis2,l,minMaxList,plot_ells=interval,main=jkPlotTextP,sub="Random Effects - Predicted Centers",xlab=pc_text1,ylab=pc_text2,jkCenter=1)
		print('End MuDiCA Jackknife Plots')
	}
	
	if(boot_sample > 99){
		bsPlotText = paste(plot_text, " Mean Confidence Interval ")
		bsPlotText = paste(bsPlotText, intervalPercentage)
		bsPlotText = paste(bsPlotText, " (")
		bsPlotText = paste(bsPlotText, boot_sample)
		bsPlotText = paste(bsPlotText, " samples)")
		print('Begin MuDiCA Bootstrap Plots')		
		bsPlot(fboots,cpsu,FALSE,axis1,axis2,showEllipse=interval,showPoints=1,minMaxList,main=bsPlotText,sub="Bootstrap",xlab=pc_text1,ylab=pc_text2,num_comparisons=num_comparisons)
		print('End MuDiCA Bootstrap Plots')
	}
	
	####################BLOCK SPECIFIC##########################
	if(plot_block_data==1){
		howMany = dim(tableContributions)[1]
		cn = colnames(X)
		dev.new()
		blockNames = rownames(Z)
		blockPlotText = paste(plot_text, "Blocks Only")
		plot(0,0,type="n",main=blockPlotText,sub="Block Barycenters",ylim=c(minMaxList$miny,minMaxList$maxy),xlim=c(minMaxList$minx,minMaxList$maxx),pos=0,xlab=pc_text1,ylab=pc_text2)
		for(j in 1:howMany){
			if((!is.nan(tableBarys[j,axis1]) && !is.nan(tableBarys[j,axis2]))){		
				text(tableBarys[j,axis1],tableBarys[j,axis2],blockNames[j],col=sample(createOriginalColorList(),1))
			}
		}
	
		if(variable_plots){
			allPlotText = paste(plot_text, " Original Group Centers, All Variables & Block Barycenters")
			varPlotter(cpsu,axis1,axis2,F,Y,G,fobs,lambda,minMaxList,1,0,vars_available=vars,datain=X,main=allPlotText,sub="Block centers, group centers and variables",xl=pc_text1,yl=pc_text2)
			for(j in 1:howMany){
				if((!is.nan(tableBarys[j,axis1]) && !is.nan(tableBarys[j,axis2]))){		
					text(tableBarys[j,axis1],tableBarys[j,axis2],blockNames[j],col=sample(createOriginalColorList(),1))
				}
			}		
		}
	}
	####################BLOCK SPECIFIC##########################
	
	####################SUPPLEMENTARY SPECIFIC##########################
	#Supplementary Points Calculations
	if(sup_mat != 0){
		print('Supplementary Points Calculations')
		Xsup = ret_data$s
		ret_RealSup <- supplementaryObservationPoints(l,Xsup,F)
		dcaPlot(cpsu,axis1,axis2,Y,G,fobs,l,minMaxList,main="Supplementary Data", sub="Fixed Effect with Supplementary Observation Projections",xlab=pc_text1,ylab=pc_text2)
		text(ret_RealSup$sup[,axis1],ret_RealSup$sup[,axis2],array("?",dim(ret_RealSup$sup[1])),col="steelblue4")
	}
	####################SUPPLEMENTARY SPECIFIC##########################


###FINAL OUTPUT, YOU CAN SAVE OR PRINT THIS STUFF###
	results = list(od=ret_data,rd=ret_DCA,rs=ret_Sup,assign=assignments,mml=minMaxList,jk=jkDCA,td=tableData,bsb=bootstrap_back,r2=ret_R2)
	return(results)	
}

minmaxHelper <- function(mat1,mat2,axis1,axis2,override=0){
	trackMinMaxMatrix <- rbind(mat1,mat2)
	minMaxList <- list(minx=min(c(trackMinMaxMatrix[,axis1],0)),miny=min(c(trackMinMaxMatrix[,axis2],0)),maxx=max(c(trackMinMaxMatrix[,axis1],0)),maxy=max(c(trackMinMaxMatrix[,axis2],0)))	
	return(list(tmm=trackMinMaxMatrix,mml=minMaxList))
}

init_results <-function(){
	print('word')

}