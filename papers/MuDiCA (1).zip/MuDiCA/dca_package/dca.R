dca <- function(X,Y,Z){
	
#The Di part of MuDiCA.
	S <- t(Y) %*% X
	
#This is the CA of MuDiCA Let Correspondce Analysis do the work.
	ca_results <- epCA(S)

#Sending away the DiCA data so MUDICA_DEMO can do the Mu part of MuDiCA
	#return(list(f=ret_CA$fj,g=ret_CA$fi,l=ret_CA$l,w=ret_CA$w,S=S,spp=ret_CA$gt,c=ret_CA$c,tau=ret_CA$t))	
	return(list(g=ca_results$fi,f=ca_results$fj,w=diag(ca_results$W),S=S,spp=sum(S),c=t((colSums(S)/sum(S))),di=ca_results$di,ci=ca_results$ci,ri=ca_results$ri,cj=ca_results$cj,rj=ca_results$rj,dj=ca_results$dj,tau=ca_results$t,pdq=ca_results$pdq,l=ca_results$pdq$Dv^2))
}
