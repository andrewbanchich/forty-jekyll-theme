## Project Webpage

Our new website is currently located at `https://readchina.github.io` and build using [GitHub pages](https://pages.github.com).

Contents come either in the form of `blogs` posts, or as `page`. To create a new post or page create contents using markdown and open a pull request. Once the pull request is merged, your contents are live within seconds.

### Running locally
After you've cloned this repository, you can preview your changes in your browser before pushing them GitHub. To view such changes locally on your computer before they are uploaded you need to install [jekyll](https://jekyllrb.com).

If you have the necessary tools installed. Open your Terminal (CLI) and type the following.

```zsh
bundle exec jekyll serve --watch
```

You should see something like this:

```zsh
Server address: http://127.0.0.1:4000
Server running... press ctrl-c to stop.
```

Simply open the [server address](http://127.0.0.1:4000) in your browser and you can see what your changes will look like on the webpage.

You would normally press `ctrl-c` to stop the server in the terminal window. If you can no longer locate that terminal here is a handy shortcut to stop the local server from a new terminal.

```
ps aux |grep jekyll |awk '{print $2}' | xargs kill -9
```

### Further Reading and Tutorials
-   [GitHub Pages Documentation](https://help.github.com/en/github/working-with-github-pages)
    -   [Running locally](https://help.github.com/en/github/working-with-github-pages/testing-your-github-pages-site-locally-with-jekyll)
-   [Programming Historian: Jekyll gh-pages Tutorial](https://programminghistorian.org/en/lessons/building-static-sites-with-jekyll-github-pages)
-   [Mastering Markdown](https://guides.github.com/features/mastering-markdown/)

**HINT**
The jekyll documentation for macOS still assumes the `bash` shell when adding ruby to your `PATH`. If you are using `zsh` on macOS catalina the command is:
```zsh
echo 'export PATH="$HOME/.gem/ruby/2.7.0/bin:$PATH"' >> ~/.zshrc
```
