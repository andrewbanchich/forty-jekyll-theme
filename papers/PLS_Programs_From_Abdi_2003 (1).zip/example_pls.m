%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% example_pls.m:  PLS example
% RM3 Fall 2004
% November 16  2004
%
%  This script shows how to run
%  a Partial least square regression
%  (PLS). 
% Need Programs: PLS_nipals plotxyha
% The example is the
% Wine example from Abdi H. (2003)
% See www.utd.edu/~herve
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
clc;
disp(['Example of a PLS program. See Abdi H. (2003)']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%************************************************************
%% -> This is your title. 
%% -> Change it to fit your data
ze_title=['PLS. Wines. '];

%% **********************************************************
%% This is the data matrix of the Predictors (IV)
%% -> Change it for your example 
X=[...
    7  7 13 7
    4  3 14 7
   10  5 12 5
   16  7 11 3
   13  3 10 3
    ];
%%%  get the # of rows and columns %%%%%%%%%%%%%%%%%%%%%%%%%%
[nI,nJ]=size(X);
%************************************************************
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% -> These are your predictors names.
% -> Change them to fit your data
% You need as many names as mcX has columns
n=0;
%
n=n+1;nom_x(n)={' Price'};
n=n+1;nom_x(n)={' Sugar'};
n=n+1;nom_x(n)={' Alcohol'};
n=n+1;nom_x(n)={' Acidity'};
%%% Test the # of colums names
if nJ~=n; 
    erreur(['Error ->  (Wrong # of column names)!']);
end
%%***********************************************************
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% -> These are your observations names.
% -> Change them to fit your data
l=0;
l=l+1;nom_r{l}={'W_1'};
l=l+1;nom_r{l}={'W_2'};
l=l+1;nom_r{l}={'W_3'};
l=l+1;nom_r{l}={'W_4'}; 
l=l+1;nom_r{l}={'W_5'}; 
if nI~=l; 
    erreur(['Error -> (Wrong # of row names)!']);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% **********************************************************
%% This is the data matrix of the Dependant Variables (DV)
%% -> Change it for your example 
Y=[...
   14 7 8
   10 7 6
    8 5 5
    2 4 7
    6 2 4
    ];
%%%  get the # of rows and columns %%%%%%%%%%%%%%%%%%%%%%%%%%
[nI2,nK]=size(Y);
%************************************************************
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% -> These are your predictors names.
% -> Change them to fit your data
% You need as many names as mcX has columns
m=0;
%
m=m+1;nom_y(m)={' Hedonic'};
m=m+1;nom_y(m)={' Meat'};
m=m+1;nom_y(m)={' Dessert'};
%%% Test the # of colums names
if nK~=m; 
    erreur(['Error ->  (Wrong # of column names)!']);
end
%%*********************************************************** 
%%%%%%%%%%%%  Call PLS_nipals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nfact2keep=2 ;
%%%  nfact gives the number of latent variables
%%%  the default is equal to the rank of X
[T,P,W,Wstar,U,b,C,Bpls,Bpls_star,Xhat,Yhat,R2X,R2Y]=...
    PLS_nipals(X,Y,nfact2keep);

%%%%%%%%%%%%  Plot the Observations (T vectors)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
percent_of_inertiaX=100*R2X; 
percent_of_inertiaY=100*R2Y; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  The axes to keep for the plots
axe_horizontal=1;
axe_vertical=2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
le_taux=[...
' {\tau_X}_',int2str(axe_horizontal),'=',...
    int2str(percent_of_inertiaX(axe_horizontal)),'%,', ...
   ' {\tau_X}_',int2str(axe_vertical),'=',...
    int2str(percent_of_inertiaX(axe_vertical)),'%', ...
              ' {\tau_Y}_',int2str(axe_horizontal),'=',...
    int2str(percent_of_inertiaY(axe_horizontal)),'%,', ...
   ' {\tau_Y}_',int2str(axe_vertical),'=',...
          int2str(percent_of_inertiaY(axe_vertical)),'%'];
%%%% Plot here %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
figure(1);clf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Now plot the Observations Scores T
%%  
ze_tRC=[ze_title,' Observations (T).'];
titre=[ze_tRC, le_taux];
plotxyha(T,1,2,titre,nom_r');
axis('equal') ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Now plot the X Scores W
%%  
figure(2);clf
ze_tRC=[ze_title,' Predictors (W).'];
titre=[ze_tRC, le_taux];
plotxyha(W,1,2,titre,nom_x');
axis('equal') ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Now plot the Y Scores U
%%  
figure(3);clf
ze_tRC=[ze_title,' DV (C -> Non Ortho).'];
titre=[ze_tRC, le_taux];
plotxyha(C,1,2,titre,nom_y');
% axis('equal') ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


