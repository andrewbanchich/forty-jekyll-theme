#inputs: 
#	datain - a multivariate data set. A 2D matrix with >=2 variables/columns and >=2 observations/rows
#	k - a value to retrieve 1-->k eigenvectors/values

#outputs:
#	returns what is returned by SVD.
#		P, Delta, Q and number of eigenvectors.
#	See PDQ for the return values.

basePCA <- function(datain,k=0){
	#a shell function to call into the PDQ() function which performs an SVD that eliminates eigenvectors/values below the machine precision value.
	#k can be used to retrieve only 1-->k number of eigenvectors/values


	#There are two functions here that effectively do the same thing - I need to double check the math, however.
	#One, is fastPDQ, which is reserved for doing BIG data
	#Second, is PDQ, which is here for tutorial purposes
	
	#These do exhibit some weirdness on higher eigenvectors/values...
	
	data_dimensions = dim(datain)
	if(data_dimensions[1] >= 25 && data_dimensions[2] >= 100){
		return(fastPDQ(datain,k))
	}else{
		return(PDQ(datain,k))
	}
	
}