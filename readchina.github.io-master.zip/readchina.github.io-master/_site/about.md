## About us

The institutional host of *READCHINA* is [Albert-Ludwigs-Universität Freiburg](http://www.uni-freiburg.de) in Germany. You can reach us at:

Institute of Chinese Studies
University of Freiburg
Belfortstr. 18 (VH)
READCHINA: The Politics of Reading in the People's Republic of China
Rooms 03 004-05
79098 Freiburg
Germany
