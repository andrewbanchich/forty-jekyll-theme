Data & Development Notes:

Some functions are clones of MatLab functions. I (Derek) did not write the following functions:

repmat
	Source: http://cran.r-project.org/doc/contrib/R-and-octave.txt
pause (modified by Derek)
	Source: https://stat.ethz.ch/pipermail/r-help/2001-November/016998.html