####
# cpsu = color point structure
# fi = F
# classes = Y
# fj = G
# fobs = calculated observations
####
varPlotter <- function(cpsu,axis1=1,axis2=2,fi,classes,fj,fobs,lambda,minMaxList,plot_centers=1,plot_points=0,vars_available=FALSE,datain,main="",sub="",xl="",yl=""){
	
	#plot the variables!
	#use steelblue4 for variable points
	#point style is fixed to 25 - coincidentally, an upside down triangle, which looks like a v!
	
	minx = minMaxList$minx
	miny = minMaxList$miny
	maxx = minMaxList$maxx
	maxy = minMaxList$maxy
	
	#plotting the rest of the data.
	if(vars_available){
		if( plot_centers == 1 || plot_points == 1 ){		
			dcaPlot(cpsu,axis1,axis2,classes,fj,fobs,lambda,minMaxList,FALSE,0,plot_centers,plot_points,main=main,sub=sub,xlab=xl,ylab=yl)
			text(fi[,axis1],fi[,axis2],colnames(datain),col="steelblue4")
			text(fj[,axis1],fj[,axis2],colnames(classes),col="red",lwd=1)
		}else{
			dev.new()
			plot(fi[,axis1],fi[,axis2],ylim=c(miny,maxy),xlim=c(minx,maxx),pch=25,col="steelblue4",pos=0,type="n",main=main,sub=sub,xlab=xl,ylab=yl)
			text(fi[,axis1],fi[,axis2],colnames(datain),col="steelblue4")
		}
	}else{
		if( plot_centers == 1 || plot_points == 1 ){
			dcaPlot(cpsu,axis1,axis2,classes,fj,fobs,lambda,minMaxList,FALSE,0,plot_centers,plot_points,main=main,sub=sub,xlab=xl,ylab=yl)
			points(fi[,axis1],fi[,axis2],ylim=c(miny,maxy),xlim=c(minx,maxx),pch=25,col="steelblue4",pos=0)
		}else{
			dev.new()
			plot(fi[,axis1],fi[,axis2],ylim=c(miny,maxy),xlim=c(minx,maxx),pch=25,col="steelblue4",pos=0,main=main,sub=sub,xlab=xl,ylab=yl)
		}
	}
	#plot fi or F
}