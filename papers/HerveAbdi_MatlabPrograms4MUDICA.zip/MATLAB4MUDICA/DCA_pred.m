function [lambda,t,d,fi,ri,ci,dj,fj,rj,cj,...
    f_obs,d_obs,c_obs,...
    Group_Assigned,ConfMat,Group_Assigned_jack,ConfMat_jack,...
    fi_sup_jack,fi_jack,f_obs_pred,DropedCol] =DCA_pred(X,Y)
    %USAGE: [lambda,t,d,fi,ri,ci,dj,fj,rj,cj,...
    % f_obs,d_obs,c_obs,Group_Assigned,ConfMat,GA_jack,CM_jack,...
    % f_obs_jack,fi_jack,f_obs_pred,DropedCol] =DCA_pred(X,Y)
    % performs a DCA -> Discriminant Correspondence Analysis
    % fixed and random models (i.e., fixed: the sample _is_ the Population
    %                          random: the sample _estimates_ the Population)    
    % reference (see www.utd.edu/~herve for reprints)
    %        Abdi, H. (2007). DCA: Discriminant correspondence analysis.
    %        Abdi, H., Williams, L.J. (2010).
    %                 BADIA: Barycentric discriminant analysis.
    %                 Correspondence analysis.
    %        Williams, L.J., Abdi, H.,  French, R., & Orange, J.B. (2010).
    %        A tutorial on Multi-Block Discriminant Correspondence Analysis 
    %        (MUDICA): A new method for
    %        analyzing discourse data from clinical populations.
    %        Journal of Speech Language and Hearing Research.
    % INPUTS: X (data matrix) nI by nJ (Ni observations, Nj variables)
    %         Y (group matrix) can be a vector of integers 
    %            or a 0/1 indicator matrix.
    %            It gives the group (g out of Ng groups)
    %            to which the observation belongs.
    % OUTPUTS:      
  % lambda is the eigenvalue vector,
  % t is the percentage of inertia vector
  %  ***  The following matrices represent the groups -> ending i ***
  % fi is the matrix of the group-coordinates
  % di is the vector of the (Chi-squared) distance to the centroid
  % ri is the matrix of the Correlation between the group and the axes
  % ci is the matrix of the Contributions
  %  ***  The following matrices represent the columns -> ending j ***
  % fj is the matrix of the column-coordinates
  % dj is the vector of the (Chi-squared) distance to the centroid
  % rj is the matrix of the Correlation between the j set and the axis
  % cj is the matrix of the Contributions
  %  ***  The following matrices represent the observations -> ending obs ***
  % f_obs is the matrix of the observation coordinates
  % d_obs is the vector of the (Chi-squared) distance to the centroid
  % c_obs is the matrix of the Contributions
  % %***  These matrices evaluate the quality or the DCA Fixed Model
  % Group_assigned is a ni by nc matrix 
  %  with 1 for the group assigned to the observation (closest center)
  %  ConfMat is a confusion matrix
  %  rows are the Assigned Groups, columns the Real Groups
  % %***  These matrices evaluate the quality or the DCA Random model
  % GA_jack  [i.e., Group_assigned_jack]  is a ni by nc matrix 
  %  with 1 for the group assigned to the observation (closest center)
  % CM_jack  [i.e., ConfMat_jack] is a confusion matrix
  %  rows are the Assigned Groups, columns the Real Groups
  % fi_obs_jack is the matrix of the coordinates of the observations
  %   when the observation was jackniffed
  % fi_jack is an array (i.e., a Ng*Nfactors*Ni matrix) of the
  %   group centers for each iteration of the jackknife.  
  % f_obs_pred are the random effect model predicted factor scores
  %   of the observation (from jackknife and backprojection)  
  %   these are sued for "prediction intervals".
  % ********************************************************************
  % DropedCol: For the jackknife, we need to drop the columns
  %            for which there is a non-sero value for only one
  %            observation (because when this observation is
  %            "in the jackknife" there is a column with a sum of zero.
  %            This creates a divide by zero error.
  %            DropedCol gives the indices of these columns.
  %            And the program gives a warning.   
  % NB When Columns are droped, the fixed effect is computed 
  %    with all the columns and the random effect is computed
  %    with only the reduced number of columns.
  %    In order to have the save set of columns for both
  %    The matrix X needs to be cleaned _before_ calling DCA_jack
  %         
  % History: January/August 2007. Corrections November 2008. HA
  % Correction September 2009 (to include predicted values)
  % Current Version February 18, 2010 Herve Abdi 
  % herve@utdallas.edu   www.utdallas.edu/~herve

  
  disp(['DICA. Computing Fixed Effect Model'])
  
    [nobs,njY]=size(Y);
    if njY==1;
        G=dummy_of(Y);
    else
        G=Y;
    end
    [nI,nc]=size(G);
% %
% % Compute the "summed table"
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Xsum=G'*X;
% %%%%%%%%%%%  Call corresp for the sum
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[lambda,t,d,fi,ri,ci,dj,fj,rj,cj] = corresp_w(Xsum) ;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Project the observations as supplementary elements
[f_obs]=afc_sup(X,fj,lambda);
% Project the sup observations as supplementary elements
% [f_isup]=afc_sup(Xsup,fj,lambda);
% %%
% %% Compute the square cosines for the sup %%%
% %% 1. the distance
% 
n_eigen=length(lambda);
fo2=f_obs.^2;
d_obs=sum(fo2,2);
c_obs=fo2./repmat(d_obs,1,n_eigen);


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%% Compute the distance matrix %%%%%%%%%
% %%%%%%%%%%%%  Between observations and Centers%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Dsup=disteucl2(f_obs,fi);
minD=min(Dsup')';
Group_Assigned=real(Dsup==repmat(minD,1,nc));
ConfMat=Group_Assigned'*G;
% %%% Check matrix formula for distance matrix %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Confmat is a confusion matrix
% % The rows are the Assigned Groups
% % The columns are the Real Groups
% % Here we have the fixed effect model
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Jackknife here
% %% Jackknife here %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Initialization
% iterations
[nJ,nL]=size(fj);
Col2Drop=find(sum(X~=0)==1);
nJ4jack=nJ;
fj4jack=fj;
if isempty(Col2Drop)~=1;
   warning(['Empty Columns Have Been Eliminated (see Col2Drop)']);
   X(:,Col2Drop)=[];
   fj4jack(Col2Drop,:)=[];
   ToKeep=1:nJ;ToKeep(Col2Drop)=[];
   nJ4jack=size(fj4jack,1);
end
Gdeltam1=fj4jack.*repmat((lambda.^(-1/2))',nJ4jack,1);
fi_sup_jack=zeros(nI,nL);
f_obs_pred=zeros(nI,nL);
Dsup_jack=zeros(nI,nc);
fi_jack=zeros(nc,length(lambda),nI);

disp(['Fixed Effect Model computed. -> Start Jackknife'])
for i=1:nI;
 leMess=(['Jackknifing: ',int2str(i),'/',int2str(nI)]);
 if i>1;    for tt=1:nle;fprintf('\b');end
      end
      fprintf('%s%',leMess);nle=length(leMess);
 Gj=G;
 Xj=X;
 le_jack=X(i,:);
 Xj(i,:)=[];
 Gj(i,:)=[];
 Xsumj=Gj'*Xj;
% %% 
% %% Possible source of problem
% %% may lose dimensions when jackknifing
% %% the decision here is to eliminate all colums with
% %% a single value of 1 in it.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 [l_j,t_j,di_j,fi_j,ri_j,ci_j,dj_j,fj_j,rj_j,cj_j,w_j]=corresp_w(Xsumj);
 fi_sup_jack(i,:)=afc_sup(le_jack,fj_j,l_j);
 if isempty(Col2Drop)~=1; % if we have dropped some columns
        % we need to use the reduced version of fj
        % but se still need to have fj correct to send back
     fi_jack(:,:,i)=afc_sup(Xsumj,fj4jack,lambda);
 else
     fi_jack(:,:,i)=afc_sup(Xsumj,fj,lambda);
 end
 Dsup_jack(i,:)=disteucl2(fi_sup_jack(i,:),fi_j);
 % Projection of random obs#i on the common solution
 li=le_jack./sum(le_jack);
% Efficient version of Eq 23. of Appendix of WAO 2010
% testh2=((l_1* (G_1.*repmat( (delta_1.^(-2))',nJ,1)))*...
%          (G_1'.*repmat(1./w_1',nL,1)))*(G.*repmat(1./delta',nJ,1))
   nLi=length(l_j);
   h_hat_i=...%
      ((li*...
      (fj_j.*repmat((l_j.^(-1))',nJ4jack,1)))*...
      (fj_j'.*repmat(1./w_j,nLi,1)))*... % 
       Gdeltam1;
  f_obs_pred(i,:)=h_hat_i;
end
fprintf('\r');
disp('Jackknife Done');
% %%% Model 2 Confusion Matrix %%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
minD_jack=min(Dsup_jack')';
Group_Assigned_jack=real(Dsup_jack==repmat(minD_jack,1,nc));
ConfMat_jack=Group_Assigned_jack'*G;


%  **********  The functions here ***************
% 1.dummy_of
% 2.corresp
% 3.eigen
% 4.afcsup
% 5.discteucl2
function  [Xrec,nom_c]=dummy_of(x)
% USAGE [Xrecnval]=dummy_of(x)
% transform a vector x into a dummy matrix X
% x is a vector with different values
% (not ordered and with possible gaps
% Xrec is dummy coding matrix
% after the values of x have been 
%   replaced by unique ordered values
% nval i a string array 
%   it gives the recoding values for x
%   (i.e. the columns of Xrec)
% Herve Abdi January 2006
[U_S,m,recS]=unique(x);
% U_S containts the "unique values of S
% recS containts the renumbered values
n_S=length(m);
% # of different values of S
ni=length(x) ;
Xrec=zeros(ni,n_S);
les_uns=sub2ind(size(Xrec),  [1:ni]',recS);
%dummy_S([ [1:ni]',recS])=ones(ni,1)
Xrec(les_uns)=1;
nval_n=x(m);
n=0;
for k=1:length(nval_n);
nom_c(k)={[num2str(nval_n(k))]}; 
end
% End of dummy_of
% corresp
function [l,t,di,fi,ri,ci,dj,fj,rj,cj,w] = corresp_w(X,nfk) ;
%usage:  [l,t,di,fi,ri,ci,dj,fj,rj,cj,w] = corresp_w(X,nfact2keep) ;
%Correspondence Analysis:  
%           X: matrix to analyze
%  nfact2keep: # of factors to keep (def=all)         
% l is the eigenvalue vector,
% t is the percentage of inertia vector
%  ***  The following matrices represent the rows -> ending i ***
% fi is the matrix of the row-coordinates
% di is the vector of the (Chi-squared) distance to the centroid
% ri is the matrix of the Correlation between the i set and the axis
% ci is the matrix of the Contributions
%  ***  The following matrices represent the columns -> ending j ***
% fj is the matrix of the column-coordinates
% dj is the vector of the (Chi-squared) distance to the centroid
% rj is the matrix of the Correlation between the j set and the axis
% cj is the matrix of the Contributions
% ***
% w is the weight vector for the J set -> needed for jackknife
% %%    Herv� Abdi April 2004/ revised September 2009 
%  See also mca for multiple correspondence analysis
% % Compute CA as a bilinear model 
 le_flip=0;
 [I,J]=size(X);
 if J<I; X=X';le_flip=1;[I,J]=size(X);end
 if exist('nfk') ~=1;nfk=I;end
 xtot=sum(sum(X)');
 xpj=sum(X);
 xip=sum(X,2);
 c=sum(X)/xtot;
 m=sum(X')/xtot;
 w=ones(1,J) ./ c ;
 Y= (X./(xip*ones(1,J)))-ones(I,1)*c;
 % % use an eigenvalue decomposition to save memory
 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[P,l]=eigen(((Y.*repmat(w,I,1))*Y').*( (m.^(1/2)')*(m.^(1/2)) ) );
 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 nf=length(l);all_l=l;
 if nf > nfk;nf=nfk;
     P=P(:,1:nf);l=l(1:nf);
 end
 P= repmat((m'.^(-1/2)),1,nf).*P;
 d=l.^(1/2);
 fi=P.*repmat(d',I,1);
 t=(l/sum(all_l))*100;
 di=(Y.^2)*w';
 ri=repmat((1./di),1,nf ).*( fi.^2);
 ci=repmat(m',1,nf).*(fi.^2)./repmat(l',I,1);
% Compute the solution for the J set using the transition formula
  Z=(X./repmat(xpj,I,1)  )';
  fj=Z*P;
  dj=( (Z-repmat(m,J,1)).^2)*(ones(1,I)./m)';
  rj=repmat((1./dj),1,nf ).*( fj.^2);
  cj=repmat(c',1,nf).*(fj.^2)./repmat(l',J,1);
%
%unflip
if le_flip==1;
    tm=fi;fi=fj;fj=tm;
    tm=di;di=dj;dj=tm;
    tm=ri;ri=rj;rj=tm;
    tm=ci;ci=cj;cj=tm;
end
% End of corresp    
% eigen 
function [U,l] = eigen(X);
% usage: [U,l]=eigen(X)
% Compute the Eigenvalues and Eigenvectors of a
% semi positive definite matrix X.
% U is the matrix of the eigenvectors.
% l is the vector of the eigenvalues.
% Eigenvectors & eigenvalues are sorted in decreasing order.
% The eigenvectors are normalized: U'* U = I.
% Eigenvalues smaller than epsilon=.000001 and
% negative eigenvalues (due to rounding errors) are set to zero.
% Herve' Abdi, September 1990.
    epsilon=eps;
%  tolerance to be considered 0 for an eigenvalue
   [U,D]=eig(X);
   D=diag(D);
   [l,k]=sort(D);
   n=length(k);
    l=l((n+1)-(1:n));
    U=U(:,k((n+1)-(1:n)));
% keep the non-zero eigen value only (tolerance=epsilon)
  pos=find(any([l';l'] > epsilon ));
  l=l(pos);
  U=U(1:n,pos);
% Normalize U -> not needed any more post matlab 6
%  U=U./( ones(n,1) * sqrt(sum(U.^2) ) )  ;
% end of eigen
% disteuclid2
function D=disteucl2(x,c)
% USAGE Y=disteucl2(X,Z)
% gives back 
% Y(I,K) matrix of the 
% squared euclidean distance
% between X(I,J) and Z(K,J)
% y(i,k)=(x[i]-z[k])'((x[i]-z[k])
% if Z is absent the distance is computed 
% between  the rows of X
%
if nargin==1;c=x;end;
[xni,xnj]=size(x);
% if xni==1;x=x';[xni,xnj]=size(x);end;
[cni,cnj]=size(c);
% if cni == 1;c=c';[cni,cnj]=size(c);end;
if cnj ~=xnj;
   error('c must have the same columns # as X ');
end
if xnj==1;
  D=(x.^2)*ones(1,cni) + ones(xni,1)*(c.^2)'-2*x*c';
else 
  x2=sum((x').^2)';c2=sum((c').^2);
  D=x2*ones(1,cni)+ones(xni,1)*c2-2*x*c';
end;
% end of disteucl2

function  [f_sup]=afc_sup(X_sup,F,l);
%USAGE [f_sup]=afc_sup(X_sup,F,l); correspondence analysis
%Compute supplementary elements for 
% Correspondence analysis
% need X_sup: the matrix of elements to compute
%             ALWAYS SUPPOSED TO BE ROWS!!!
%      F    : the coordinates of the other set
%              (i.e., if X_sup are rows F is G_i
%               the columns coordinates)
%      l    :  vector of the eigenvalues
%
%%%%%%%%%%%   Herve Abdi October 2004 %%%%%%%%%%%%%%
[n_sup,nvar]=size(X_sup);
[nvar2,nl]=size(F);
[nl2,toto]=size(l);
 if toto~=1;l=l';[nl2,toto]=size(l);end;
 if toto~=1;error('eigenvalues should be a vector');end
 if nvar~=nvar2;error('Dimensions fo X_sup and F should match');end
 if nl~=nl2;error('Dimensions of F and l should match');end

inv_delta=l.^(-1/2);
profile=X_sup./((sum(X_sup')')*ones(1,nvar) );
f_sup=profile*F*diag(inv_delta);

